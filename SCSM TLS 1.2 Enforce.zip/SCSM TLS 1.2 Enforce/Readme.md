![Example](/media/git-guidance/projects/tlsenforce_scsm.png)

#Introduction
This script will:

- Ensure the environment is supported for TLS 1.2
- Determine the local SCSM roles installed.
- Ensure the SCSM Roles are patched with the correct UR level to continue
- Ensure a supported version of .NET framework is installed
- Ensure that SQL is a supported version for TLS 1.2
- Ensure the software prereqs are installed (SQL Client and ODBC driver update)
- Install software prereqs if they are missing
- Configure the registry for SCHANNEL protocols, .NET hardening, and ACS ODBC driver where required.
- Prompt to reboot the server to make the changes active.
- It can be run on Management Server, Gateway, Reporting, Web Console, ACS Collectors, SQL database servers, anywhere you want TLS 1.2 enforced.
- The script just needs to be copied to a directory one each server, along with the software prerequisite files.

The software prereqs are:

- SQL Client 11 (sqlncli.msi)
- ODBC Driver 13 (msodbcsql.msi)
Download these files, and just drop them in the same directory as the script.  If they are not installed, the script will install them.

You must log on to each server as a Local Administrator, and if running on a Management Server or Web Console server, you must have rights to connect to and query the master database for the SQL instance that hosts your Service Manager databases.