![Example](/media/git-guidance/projects/tlsenforce_scom.png)

#Introduction
https://kevinholman.com/2018/05/06/implementing-tls-1-2-enforcement-with-scom/

This script will:

- Ensure the environment is supported for TLS 1.2
- Determine the local SCOM roles installed.
- Ensure the SCOM Roles are patched with the correct UR level to continue
- Ensure a supported version of .NET framework is installed
- Ensure that SQL is a supported version for TLS 1.2
- Ensure the software prereqs are installed (SQL Client and ODBC driver update)
- Install software prereqs if they are missing
- Configure the registry for SCHANNEL protocols, .NET hardening, and ACS ODBC driver where required.
- Prompt to reboot the server to make the changes active.
- It can be run on Management Server, Gateway, Reporting, Web Console, ACS Collectors, SQL database servers, anywhere you want TLS 1.2 enforced.
- The script just needs to be copied to a directory one each server, along with the software prerequisite files.

The software prereqs are:

- SQL Client 11 (sqlncli.msi)
- ODBC Driver 13 or 17 (msodbcsql.msi) (Version 17 is included in this zip)
Download these files, and just drop them in the same directory as the script.  If they are not installed, the script will install them.

You must log on to each server as a Local Administrator, and if running on a Management Server or Web Console server, you must have rights to connect to and query the master database for the SQL instance that hosts your OperationsManager and DW databases.