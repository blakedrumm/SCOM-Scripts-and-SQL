﻿--Top 20 performance insertions by perf object and counter name: 
SELECT TOP 20 pcv.ObjectName,
 pcv.CounterName,  pcv.RuleId, Rules.RuleName,
 COUNT (pcv.countername) AS Total
FROM performancedataallview AS pdv, performancecounterview AS pcv, Rules AS Rules
WHERE (pdv.performancesourceinternalid = pcv.performancesourceinternalid) AND (Rules.RuleId = pcv.RuleId)
GROUP BY pcv.objectname, pcv.countername, pcv.RuleId, Rules.RuleName
ORDER BY COUNT (pcv.countername) DESC