SELECT
   UserRoleName,
   IsSystem 
from
   userrole