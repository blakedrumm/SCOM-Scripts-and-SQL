SELECT DisplayName, 
Version, 
ActionAccountIdentity, 
ProxyingEnabled, 
HeartbeatInterval, 
IsManuallyInstalled, 
IsAgent, 
IsGateway, 
IsManagementServer,
PatchList
FROM MTV_HealthService
