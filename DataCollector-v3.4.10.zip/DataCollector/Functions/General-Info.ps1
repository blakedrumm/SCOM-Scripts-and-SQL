function Get-SCOMGeneralInfo
{
	param
	(
		[Parameter(Position = 1)]
		[array]$Servers
	)
	foreach ($server in $Servers)
	{
		. $ScriptPath`\Functions\ProductVersions\ProductVersion.ps1
		if ($server -eq $Comp)
		{
			$global:setuplocation = get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup" | Select-Object * -exclude PSPath, PSParentPath, PSChildName, PSProvider, PSDrive
			$location = $setuplocation.InstallDirectory
			Write-Host "-" -NoNewline -ForegroundColor Green
			$ServerVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocation.ServerVersion)
			$LocalServerVersionSwitchOut = $ServerVersionSwitch + " (" + $setuplocation.ServerVersion + ")"
			
			$serverdll = Get-Item "$location`MOMAgentManagement.dll" | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
			
			$ServerVersionDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $serverdll)
			$ServerVersionDLL = $ServerVersionDLLSwitch + " (" + $serverdll + ")"
			
			try
			{
				$UIDLL = Get-Item "$location`..\Console\Microsoft.EnterpriseManagement.Monitoring.Console.exe" -ErrorAction Stop | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
				if (($setuplocation.UIVersion) -and ($UIDLL))
				{
					$UIVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocation.UIVersion)
					$setuplocation.UIVersion = $UIVersionSwitch + " (" + $setuplocation.UIVersion + ")"
					
					$UIVersionDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $UIDLL)
					$UIVersionDLL = $UIVersionDLLSwitch + " (" + $UIDLL + ")"
					$UI_info = $true
				}
				
			}
			catch
			{
				$UI_info = $false
			}
			try
			{
				$WebConsoleDLL = Get-Item "$location`..\WebConsole\WebHost\bin\Microsoft.Mom.Common.dll" -ErrorAction SilentlyContinue | foreach-object { "{0}`t{1}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
				if ($null -eq $WebConsoleDLL)
				{
					$WebConsoleDLL = Get-Item "$location`..\WebConsole\Microsoft.Mom.Common.dll" -ErrorAction Stop | foreach-object { "{0}`t{1}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
				}
				$WebConsoleDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $WebConsoleDLL)
				$WebConsoleVersionDLL = $WebConsoleDLLSwitch + " (" + $WebConsoleDLL + ")"
				$WebConsole_info = $true
			}
			catch { $WebConsole_info = $false }
			$CurrentVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocation.CurrentVersion)
			$MOMmgmtGroupInfoImport = Import-Csv "$OutputPath`\MOMManagementGroupInfo.csv"
			$DBVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $MOMmgmtGroupInfoImport.DBVersion)
			$MOMmgmtGroupInfo = $DBVersionSwitch + " (" + $MOMmgmtGroupInfoImport.DBVersion + ")"
			$ManagementGroupProductVersion = Import-Csv "$OutputPath`\MOMManagementGroupInfo.csv"
			$ManagementGroupProductVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $MOMmgmtGroupInfoImport.DBVersion)
			$ManagementGroupProductVersionInfo = $ManagementGroupProductVersionSwitch + " (" + $ManagementGroupProductVersion.DBVersion + ")"
			$setuplocation.CurrentVersion = $CurrentVersionSwitch + " (" + $setuplocation.CurrentVersion + ")"
			
			Write-Host "-" -NoNewline -ForegroundColor Green
			
			$OMSQLPropertiesImport = Import-Csv "$OutputPath`\SQL_Properties_OM.csv"
			##########################################
			#########################################
			#####################################
			################################
			$OMSQLVersionSwitch = (Get-ProductVersion -Product SQL -BuildVersion $OMSQLPropertiesImport.ProductVersion)
			$OMSQLProperties = $OMSQLVersionSwitch + "`n(" + ($OMSQLPropertiesImport).ProductVersion + ") -" + " (" + ($OMSQLPropertiesImport).ProductLevel + ")" + " - " + ($OMSQLPropertiesImport).Edition
			if ($OMSQLPropertiesImport.IsClustered -eq 1)
			{
				$OMSQLProperties = $OMSQLProperties + "`n" + "[Clustered]"
			}
			try
			{
				if ($true -eq $OMSQLPropertiesImport.Is_Broker_Enabled)
				{
					$OMSQLProperties = $OMSQLProperties + "`n" + "[Broker Enabled]"
				}
				else
				{
					$OMSQLProperties = $OMSQLProperties + "`n" + "[Broker Not Enabled]"
				}
			}
			catch
			{
				$OMSQLProperties = $OMSQLProperties + "`n" + "[Broker Not Found or Disabled]"
			}
			if ($OMSQLPropertiesImport.IsFullTextInstalled -eq 1)
			{
				$OMSQLProperties = $OMSQLProperties + "`n" + "[FullText Installed]"
			}
			if ($OMSQLPropertiesImport.Collation -ne 'SQL_Latin1_General_CP1_CI_AS')
			{
				$OMSQLProperties = $OMSQLProperties + " - " + "[ISSUE: " + $OMSQLPropertiesImport.Collation + "] <------------"
			}
			$OMSQLProperties = $OMSQLProperties + "`n"
			Write-Host "-" -NoNewline -ForegroundColor Green
			$DWSQLPropertiesImport = Import-Csv "$OutputPath`\SQL_Properties_DW.csv"
			$DWSQLVersionSwitch = (Get-ProductVersion -Product SQL -BuildVersion $DWSQLPropertiesImport.ProductVersion)
			$DWSQLProperties = $DWSQLVersionSwitch + "`n(" + ($DWSQLPropertiesImport).ProductVersion + ") - (" + ($DWSQLPropertiesImport).ProductLevel + ") - " + ($DWSQLPropertiesImport).Edition
			if ($DWSQLPropertiesImport.IsClustered -eq 1)
			{
				$DWSQLProperties = $DWSQLProperties + "`n" + "[Clustered]"
			}
			try
			{
				if ($true -eq $DWSQLPropertiesImport.Is_Broker_Enabled)
				{
					$DWSQLProperties = $DWSQLProperties + "`n" + "[Broker Enabled]"
				}
				else
				{
					$DWSQLProperties = $DWSQLProperties + "`n" + "[Broker Not Enabled]"
				}
			}
			catch
			{
				$DWSQLProperties = $DWSQLProperties + "`n" + "[Broker Not Found or Disabled]"
			}
			if ($DWSQLPropertiesImport.IsFullTextInstalled -eq 1)
			{
				$DWSQLProperties = $DWSQLProperties + "`n" + "[FullText Installed]"
			}
			if ($DWSQLPropertiesImport.Collation -ne 'SQL_Latin1_General_CP1_CI_AS')
			{
				$DWSQLProperties = $DWSQLProperties + "`n" + "(ISSUE: " + $DWSQLPropertiesImport.Collation + ") <------------"
			}
			$installdir = (Resolve-Path $location`..\)
			$rmsEmulator = Get-SCOMRMSEmulator | Select-Object -Property DisplayName -ExpandProperty DisplayName
			$OSVersion = (Get-WMIObject win32_operatingsystem).Caption
			Write-Host "-" -NoNewline -ForegroundColor Green
			$ManagementGroup = Get-SCOMManagementGroup | Select-Object -Property Name -ExpandProperty Name
			#$GatewayDLL = Get-Item "C:\Program Files\System Center Operations Manager\Gateway\MOMAgentManagement.dll" | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
			$localServices = (Get-WmiObject Win32_service).where{ $_.name -eq 'omsdk' -or $_.name -eq 'cshost' -or $_.name -eq 'HealthService' -or $_.name -eq 'System Center Management APM' -or $_.name -eq 'AdtAgent' } | Format-List @{ Label = "Service Display Name"; Expression = 'DisplayName' }, @{ Label = "Service Name"; Expression = 'Name' }, @{ Label = "Account Name"; Expression = 'StartName' }, @{ Label = "Start Mode"; Expression = 'StartMode' }, @{ Label = "Current State"; Expression = 'State' } | Out-String
			$LastUpdatedConfiguration = (Get-EventLog 'Operations Manager' | where { $_.EventID -eq 1210 } | Select-Object -First 1) | Select-Object -Property TimeGenerated -ExpandProperty TimeGenerated
			if (!$LastUpdatedConfiguration) { $LastUpdatedConfiguration = "No Event ID 1210 Found in Operations Manager Event Log" }
			# Get PowerShell Version section
			#=======================================================================
			$PSVer = $PSVersionTable.PSVersion
			[string]$PSMajor = $PSVer.Major
			[string]$PSMinor = $PSVer.Minor
			$PSVersion = $PSMajor + "." + $PSMinor
			#=======================================================================
			# Get PowerShell CLR Version section
			#=======================================================================
			$CLRVer = $PSVersionTable.CLRVersion
			[string]$CLRMajor = $CLRVer.Major
			[string]$CLRMinor = $CLRVer.Minor
			$CLRVersion = $CLRMajor + "." + $CLRMinor
			#=======================================================================	
			$Freespace = Get-PSDrive -PSProvider FileSystem | Select-Object @{ Name = 'Drive'; Expression = { $_.Root } }, @{ Name = "Used (GB)"; Expression = { "{0:###0.00}" -f ($_.Used / 1GB) } }, @{ Name = "Free (GB)"; Expression = { "{0:###0.00}" -f ($_.Free / 1GB) } }, @{ Name = "Total (GB)"; Expression = { "{0:###0.00}" -f (($_.Free / 1GB) + ($_.Used / 1GB)) } }
			#=======================================================================
			# Build IP List from Windows Computer Property
			#=======================================================================
			#We want to remove Link local IP
			$ip = ([System.Net.Dns]::GetHostAddresses($Env:COMPUTERNAME)).IPAddressToString;
			[string]$IPList = ""
			$IPSplit = $IP.Split(",")
			FOREACH ($IPAddr in $IPSplit)
			{
				[string]$IPAddr = $IPAddr.Trim()
				IF (!($IPAddr.StartsWith("fe80") -or $IPAddr.StartsWith("169.254")))
				{
					$IPList = $IPList + $IPAddr + ","
				}
			}
			$IPList = $IPList.TrimEnd(",")
			#=======================================================================
			#=======================================================================
			# Get Certificate Section
			#=======================================================================
			$CertRegKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"
			IF (Test-Path $CertRegKey)
			{
				[array]$CertValue = (Get-ItemProperty $CertRegKey).ChannelCertificateSerialNumber
				IF ($Certvalue)
				{
					$CertLoaded = $True
					[string]$ThumbPrint = (Get-ItemProperty $CertRegKey).ChannelCertificateHash
					$Cert = Get-ChildItem -path cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $ThumbPrint }
					IF ($Cert)
					{
						[datetime]$CertExpiresDateTime = $Cert.NotAfter
						[string]$CertExpires = $CertExpiresDateTime.ToShortDateString()
						$CertIssuerArr = $Cert.Issuer
						$CertIssuerSplit = $CertIssuerArr.Split(",")
						[string]$CertIssuer = $CertIssuerSplit[0].TrimStart("CN=")
					}
					ELSE
					{
						$CertIssuer = "NotFound"
						$CertExpires = "NotFound"
					}
					
				}
				ELSE
				{
					$CertLoaded = $False
				}
			}
			ELSE
			{
				$CertLoaded = $False
			}
			# Get TLS12Enforced Section
			#=======================================================================
			#Set the value to good by default then look for any bad or missing settings
			$TLS12Enforced = $True
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server").DisabledByDefault
				IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client").DisabledByDefault
				IF ($Enabled -ne 1 -or $DisabledByDefault -ne 0)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server")
			{
				$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server").Enabled
				$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server").DisabledByDefault
				IF ($Enabled -ne 1 -or $DisabledByDefault -ne 0)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319")
			{
				$SchUseStrongCrypto = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319").SchUseStrongCrypto
				IF ($SchUseStrongCrypto -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			
			IF (Test-Path "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319")
			{
				$SchUseStrongCrypto = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319").SchUseStrongCrypto
				IF ($SchUseStrongCrypto -ne 1)
				{
					$TLS12Enforced = $False
				}
			}
			ELSE
			{
				$TLS12Enforced = $False
			}
			$WorkflowCount = $null
			$WorkflowCount = (((Get-Counter -Counter '\Health Service\Workflow Count' -SampleInterval 5 -MaxSamples 5).CounterSamples).CookedValue | Measure-Object -Average).Average
			#=======================================================================
			$setupOutput = @()
			if ($UI_info)
			{
				$setupOutput += [pscustomobject]@{
					'Computer Name'		     = $env:COMPUTERNAME
					'Workflow Count'		 = $WorkflowCount
					'IP Address'			 = $IPList
					'OS Version'			 = $OSVersion
					'Management Server Port' = $setuplocation.ManagementServerPort
					'Product'			     = $setuplocation.Product
					'Installed On'		     = $setuplocation.InstalledOn
					'Current Version (Registry)' = $setuplocation.CurrentVersion
					'Server Version (Registry)' = $LocalServerVersionSwitchOut
					'               (DLL)'   = $ServerVersionDLL
					'UI Version (Registry)'  = $setuplocation.UIVersion
					'           (DLL)'	     = $UIVersionDLL
					'DB Version (Query)'	 = $MOMmgmtGroupInfo
					'DW DB Version (Query)'  = $ManagementGroupProductVersionInfo
				}
			}
			else
			{
				$setupOutput += [pscustomobject]@{
					'Computer Name'		     = $env:COMPUTERNAME
					'Workflow Count'		 = $WorkflowCount
					'IP Address'			 = $IPList
					'OS Version'			 = $OSVersion
					'Management Server Port' = $setuplocation.ManagementServerPort
					'Product'			     = $setuplocation.Product
					'Installed On'		     = $setuplocation.InstalledOn
					'Current Version (Registry)' = $setuplocation.CurrentVersion
					'Server Version (Registry)' = $LocalServerVersionSwitchOut
					'               (DLL)'   = $ServerVersionDLL
					'DB Version (Query)'	 = $MOMmgmtGroupInfo
					'DW DB Version (Query)'  = $ManagementGroupProductVersionInfo
				}
			}
			if ($WebConsole_info)
			{
				$setupOutput += [pscustomobject]@{ 'Web Console Version' = $WebConsoleVersionDLL; }
			}
			$setupOutput += [pscustomobject]@{
				'Installation Directory'				 = $installdir
				'Management Group Name'				     = $ManagementGroup
				'Management Servers in Management Group' = "$ManagementServers"
				'Remote Management Server Emulator (Primary Server)' = "$rmsEmulator"
				'Free Space'							 = $Freespace | Out-String
				'Certificate Loaded'					 = $CertLoaded
				'TLS 1.2 Enforced'					     = $TLS12Enforced
				'Last Time Configuration Updated'	     = $LastUpdatedConfiguration | Get-Date -Format "MMMM dd, yyyy h:mm tt"
				'Current System Time'				     = Get-Date -Format "MMMM dd, yyyy h:mm tt"
				'Powershell Version'					 = $PSVersion
				'CLR Version'						     = $CLRVersion
			}
			if ('7.2.11719.0' -ge $setuplocationRemote.ServerVersion) # SCOM 2016 RTM
			{
				try { $UseMIAPI = (Get-Item 'HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup\UseMIAPI' -ErrorAction Stop | Select-Object Name, Property).Property } # https://docs.microsoft.com/en-us/system-center/scom/whats-new-in-om?view=sc-om-2019#scalability-improvement-with-unix-or-linux-agent-monitoring
				catch [System.Management.Automation.RuntimeException]{ $UseMIAPI = 'Not Set (or Unknown)' }
				$setupOutput += [pscustomobject]@{ 'UseMIAPI Registry' = $UseMIAPI; }
			}
			$setupOutput += [pscustomobject]@{
				'Services' = $localServices;
			}
			$dbOutput = [pscustomobject]@{
				'Operations Manager DB Server Name' = $setuplocation.DatabaseServerName
				'Operations Manager DB Name'	    = $setuplocation.DatabaseName
				'Operations Manager SQL Properties' = $OMSQLProperties
				'Data Warehouse DB Server Name'	    = $setuplocation.DataWarehouseDBServerName
				'Data Warehouse DB Name'		    = $setuplocation.DataWarehouseDBName
				'Data Warehouse SQL Properties'	    = $DWSQLProperties
			}
			Write-Host "-" -NoNewline -ForegroundColor Green
			$UserRolesImport = Import-Csv "$OutputPath`\UserRoles.csv"
			$UserRoles = "User Role Name" + " - " + "Is System?" + "`n----------------------------`n"
			$UserRolesImport | % {
				if ($_.IsSystem -eq $false)
				{
					$foundFalse = $true
					$UserRoles += $_.UserRoleName + " - " + $_.IsSystem + "`n"
				}
			}
			if ($foundFalse)
			{
				$dbOutput | Add-Member -MemberType NoteProperty -Name 'User Roles (Non-Default)' -Value $UserRoles
			}
			"================================ `
=---- General  Information ----= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
			$setupOutput | Out-File -FilePath "$OutputPath\General Information.txt" -Append
		}
		else
		{
			$setupOutput = $null
			$ProductVersionScript = "function Get-ProductVersion { ${function:Get-ProductVersion} }"
			$setupOutputRemote = Invoke-Command -ComputerName $server -ArgumentList $ProductVersionScript -ScriptBlock {
				Param ($ProductVersionScript)
				. ([ScriptBlock]::Create($ProductVersionScript))
				try
				{
					$setuplocationRemote = get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup" -ErrorAction Stop | Select-Object * -exclude PSPath, PSParentPath, PSChildName, PSProvider, PSDrive
				}
				catch
				{
					continue
				}
				$location = $setuplocationRemote.InstallDirectory
				Write-Host "-" -NoNewline -ForegroundColor Green
				if ($setuplocationRemote.Product -eq 'Microsoft Monitoring Agent')
				{
					$installdir = (Resolve-Path $location`..\)
					$OSVersion = (Get-WMIObject win32_operatingsystem).Caption
					Write-Host "-" -NoNewline -ForegroundColor Green
					#$GatewayDLL = Get-Item "C:\Program Files\System Center Operations Manager\Gateway\MOMAgentManagement.dll" | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
					$localServices = (Get-WmiObject Win32_service).where{ $_.name -eq 'omsdk' -or $_.name -eq 'cshost' -or $_.name -eq 'HealthService' -or $_.name -eq 'System Center Management APM' -or $_.name -eq 'AdtAgent' } | Format-List @{ Label = "Service Display Name"; Expression = 'DisplayName' }, @{ Label = "Service Name"; Expression = 'Name' }, @{ Label = "Account Name"; Expression = 'StartName' }, @{ Label = "Start Mode"; Expression = 'StartMode' }, @{ Label = "Current State"; Expression = 'State' } | Out-String
					#$ManagementGroups = Get-Item "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Agent Management Groups\*" | Select-Object PSChildName -ExpandProperty PSChildName
					$ADIntegration = (Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\HealthService\Parameters\ConnectorManager).EnableADIntegration
					
					$ADIntegrationSwitch = switch ($ADIntegration)
					{
						'0' { "Disabled" }
						'1' { "Enabled" }
					}
					$LastUpdatedConfiguration = (Get-EventLog 'Operations Manager' | where { $_.EventID -eq 1210 } | Select-Object -First 1) | Select-Object -Property TimeGenerated -ExpandProperty TimeGenerated
					if (!$LastUpdatedConfiguration) { $LastUpdatedConfiguration = "No Event ID 1210 Found in Operations Manager Event Log" }
					# Get PowerShell Version section
					#=======================================================================
					$PSVer = $PSVersionTable.PSVersion
					[string]$PSMajor = $PSVer.Major
					[string]$PSMinor = $PSVer.Minor
					$PSVersion = $PSMajor + "." + $PSMinor
					#=======================================================================
					$Freespace = Get-PSDrive -PSProvider FileSystem | Select-Object @{ Name = 'Drive'; Expression = { $_.Root } }, @{ Name = "Used (GB)"; Expression = { "{0:###0.00}" -f ($_.Used / 1GB) } }, @{ Name = "Free (GB)"; Expression = { "{0:###0.00}" -f ($_.Free / 1GB) } }, @{ Name = "Total (GB)"; Expression = { "{0:###0.00}" -f (($_.Free / 1GB) + ($_.Used / 1GB)) } }
					[string]$SCOMAgentURVersion = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocationRemote.CurrentVersion -Agent)
					# Load Agent Scripting Module
					#=======================================================================
					$AgentCfg = New-Object -ComObject "AgentConfigManager.MgmtSvcCfg"
					#=======================================================================
					
					# Get Agent Management groups section
					#=======================================================================
					#Get management groups
					$MGs = $AgentCfg.GetManagementGroups()
					
					#Loop through each and create a comma seperated list
					FOREACH ($MG in $MGs)
					{
						$MGList = $MGList + $MG.managementGroupName + ", "
					}
					$MGlist = $MGlist.TrimEnd(", ")
					# Get Agent OMS Workspaces section
					#=======================================================================
					# This section depends on AgentConfigManager.MgmtSvcCfg object in previous section
					[string]$OMSList = ''
					# Agent might not support OMS
					$AgentSupportsOMS = $AgentCfg | Get-Member -Name 'GetCloudWorkspaces'
					IF (!$AgentSupportsOMS)
					{
						#This agent version does not support Cloud Workspaces.
					}
					ELSE
					{
						$OMSWorkSpaces = $AgentCfg.GetCloudWorkspaces()
						FOREACH ($OMSWorkSpace in $OMSWorkSpaces)
						{
							$OMSList = $OMSList + $OMSWorkspace.workspaceId + ", "
						}
						IF ($OMSList)
						{
							$OMSList = $OMSList.TrimEnd(", ")
						}
						
						#Get ProxyURL
						[string]$ProxyURL = $AgentCfg.proxyUrl
					}
					# Get PowerShell CLR Version section
					#=======================================================================
					$CLRVer = $PSVersionTable.CLRVersion
					[string]$CLRMajor = $CLRVer.Major
					[string]$CLRMinor = $CLRVer.Minor
					$CLRVersion = $CLRMajor + "." + $CLRMinor
					#=======================================================================
					# Get Certificate Section
					#=======================================================================
					$CertRegKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"
					IF (Test-Path $CertRegKey)
					{
						[array]$CertValue = (Get-ItemProperty $CertRegKey).ChannelCertificateSerialNumber
						IF ($Certvalue)
						{
							$CertLoaded = $True
							[string]$ThumbPrint = (Get-ItemProperty $CertRegKey).ChannelCertificateHash
							$Cert = Get-ChildItem -path cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $ThumbPrint }
							IF ($Cert)
							{
								[datetime]$CertExpiresDateTime = $Cert.NotAfter
								[string]$CertExpires = $CertExpiresDateTime.ToShortDateString()
								$CertIssuerArr = $Cert.Issuer
								$CertIssuerSplit = $CertIssuerArr.Split(",")
								[string]$CertIssuer = $CertIssuerSplit[0].TrimStart("CN=")
							}
							ELSE
							{
								$CertIssuer = "NotFound"
								$CertExpires = "NotFound"
							}
							
						}
						ELSE
						{
							$CertLoaded = $False
						}
					}
					ELSE
					{
						$CertLoaded = $False
					}
					# Build IP List from Windows Computer Property
					#=======================================================================
					#We want to remove Link local IP
					$ip = ([System.Net.Dns]::GetHostAddresses($Env:COMPUTERNAME)).IPAddressToString;
					[string]$IPList = ""
					$IPSplit = $IP.Split(",")
					FOREACH ($IPAddr in $IPSplit)
					{
						[string]$IPAddr = $IPAddr.Trim()
						IF (!($IPAddr.StartsWith("fe80") -or $IPAddr.StartsWith("169.254")))
						{
							$IPList = $IPList + $IPAddr + ","
						}
					}
					$IPList = $IPList.TrimEnd(",")
					$SCOMAgentVersion = $SCOMAgentURVersion + " (" + $setuplocationRemote.CurrentVersion + ")"
					
					$setupOutputRemote = [pscustomobject]@{
						'Computer Name' = $env:COMPUTERNAME
						'IP Address'    = $IPList
						'OS Version'    = $OSVersion
						'Product'	    = $setuplocationRemote.Product
						'Installed On'  = $setuplocationRemote.InstalledOn
						'Current Version (Registry)' = $SCOMAgentVersion
						'AD Integration' = $ADIntegrationSwitch
						'Installation Directory' = $installdir
						'Management Groups' = $MGlist
						'Agent OMS Workspaces' = $OMSList
						'Proxy URL'	    = $ProxyURL
						'Certificate Loaded' = $CertLoaded
						'Last Time Configuration Updated (1210 EventID)' = $LastUpdatedConfiguration | Get-Date -Format "MMMM dd, yyyy h:mm tt"
						'Current System Time' = Get-Date -Format "MMMM dd, yyyy h:mm tt"
						'Powershell Version' = $PSVersion
						'CLR Version'   = $CLRVersion
						'Free Space'    = $Freespace
					}
					$setupOutputRemote | Add-Member -MemberType NoteProperty -Name 'Services' -Value $localServices
					return $setupOutputRemote
				}
				
				$ServerVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocationRemote.ServerVersion)
				$RemoteServerVersionSwitchOut = $ServerVersionSwitch + " (" + $setuplocationRemote.ServerVersion + ")"
				
				$serverdll = Get-Item "$location`MOMAgentManagement.dll" | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
				$ServerVersionDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $serverdll)
				$ServerVersionDLL = $ServerVersionDLLSwitch + " (" + $serverdll + ")"
				
				try
				{
					$UIDLL = Get-Item "$location`..\Console\Microsoft.EnterpriseManagement.Monitoring.Console.exe" -ErrorAction Stop | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
					if (($setuplocationRemoteUIVersion) -and ($UIDLL))
					{
						$UIVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocationRemoteUIVersion)
						$setuplocationRemoteUIVersion = $UIVersionSwitch + " (" + $setuplocationRemoteUIVersion + ")"
						
						$UIVersionDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $UIDLL)
						$UIVersionDLL = $UIVersionDLLSwitch + " (" + $UIDLL + ")"
						$UI_info = $true
					}
					
				}
				catch
				{
					$UI_info = $false
				}
				try
				{
					$WebConsoleDLL = Get-Item "$location`..\WebConsole\WebHost\bin\Microsoft.Mom.Common.dll" -ErrorAction SilentlyContinue | foreach-object { "{0}`t{1}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
					if ($null -eq $WebConsoleDLL)
					{
						$WebConsoleDLL = Get-Item "$location`..\WebConsole\Microsoft.Mom.Common.dll" -ErrorAction Stop | foreach-object { "{0}`t{1}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
					}
					else
					{
						$WebConsoleDLLSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $WebConsoleDLL)
						$WebConsoleVersionDLL = $WebConsoleDLLSwitch + " (" + $WebConsoleDLL + ")"
						$WebConsole_info = $true
					}
					
				}
				catch { $WebConsole_info = $false }
				
				$CurrentVersionSwitch = (Get-ProductVersion -Product SCOM -BuildVersion $setuplocationRemote.CurrentVersion)
				$setuplocationRemote.CurrentVersion = $CurrentVersionSwitch + " (" + $setuplocationRemote.CurrentVersion + ")"
				$installdir = (Resolve-Path $location`..\)
				Write-Host "-" -NoNewline -ForegroundColor Green
				#$GatewayDLL = Get-Item "C:\Program Files\System Center Operations Manager\Gateway\MOMAgentManagement.dll" | foreach-object { "{0}" -f [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }
				$OSVersion = (Get-WMIObject win32_operatingsystem).Caption
				$localServices = (Get-WmiObject Win32_service).where{ $_.name -eq 'omsdk' -or $_.name -eq 'cshost' -or $_.name -eq 'HealthService' -or $_.name -eq 'System Center Management APM' -or $_.name -eq 'AdtAgent' } | Format-List @{ Label = "Service Display Name"; Expression = 'DisplayName' }, @{ Label = "Service Name"; Expression = 'Name' }, @{ Label = "Account Name"; Expression = 'StartName' }, @{ Label = "Start Mode"; Expression = 'StartMode' }, @{ Label = "Current State"; Expression = 'State' } | Out-String
				$LastUpdatedConfiguration = (Get-EventLog 'Operations Manager' | where { $_.EventID -eq 1210 } | Select-Object -First 1) | Select-Object -Property TimeGenerated -ExpandProperty TimeGenerated
				if (!$LastUpdatedConfiguration) { $LastUpdatedConfiguration = "No Event ID 1210 Found in Operations Manager Event Log" }
				# Get PowerShell Version section
				#=======================================================================
				$PSVer = $PSVersionTable.PSVersion
				[string]$PSMajor = $PSVer.Major
				[string]$PSMinor = $PSVer.Minor
				$PSVersion = $PSMajor + "." + $PSMinor
				#=======================================================================
				$Freespace = Get-PSDrive -PSProvider FileSystem | Select-Object @{ Name = 'Drive'; Expression = { $_.Root } }, @{ Name = "Used (GB)"; Expression = { "{0:###0.00}" -f ($_.Used / 1GB) } }, @{ Name = "Free (GB)"; Expression = { "{0:###0.00}" -f ($_.Free / 1GB) } }, @{ Name = "Total (GB)"; Expression = { "{0:###0.00}" -f (($_.Free / 1GB) + ($_.Used / 1GB)) } }
				# Get PowerShell CLR Version section
				#=======================================================================
				$CLRVer = $PSVersionTable.CLRVersion
				[string]$CLRMajor = $CLRVer.Major
				[string]$CLRMinor = $CLRVer.Minor
				$CLRVersion = $CLRMajor + "." + $CLRMinor
				#=======================================================================
				# Build IP List from Windows Computer Property
				#=======================================================================
				#We want to remove Link local IP
				$ip = ([System.Net.Dns]::GetHostAddresses($Env:COMPUTERNAME)).IPAddressToString;
				[string]$IPList = ""
				$IPSplit = $IP.Split(",")
				FOREACH ($IPAddr in $IPSplit)
				{
					[string]$IPAddr = $IPAddr.Trim()
					IF (!($IPAddr.StartsWith("fe80") -or $IPAddr.StartsWith("169.254")))
					{
						$IPList = $IPList + $IPAddr + ","
					}
				}
				$IPList = $IPList.TrimEnd(",")
				#=======================================================================
				# Get Certificate Section
				#=======================================================================
				$CertRegKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"
				IF (Test-Path $CertRegKey)
				{
					[array]$CertValue = (Get-ItemProperty $CertRegKey).ChannelCertificateSerialNumber
					IF ($Certvalue)
					{
						$CertLoaded = $True
						[string]$ThumbPrint = (Get-ItemProperty $CertRegKey).ChannelCertificateHash
						$Cert = Get-ChildItem -path cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $ThumbPrint }
						IF ($Cert)
						{
							[datetime]$CertExpiresDateTime = $Cert.NotAfter
							[string]$CertExpires = $CertExpiresDateTime.ToShortDateString()
							$CertIssuerArr = $Cert.Issuer
							$CertIssuerSplit = $CertIssuerArr.Split(",")
							[string]$CertIssuer = $CertIssuerSplit[0].TrimStart("CN=")
						}
						ELSE
						{
							$CertIssuer = "NotFound"
							$CertExpires = "NotFound"
						}
						
					}
					ELSE
					{
						$CertLoaded = $False
					}
				}
				ELSE
				{
					$CertLoaded = $False
				}
				# Get TLS12Enforced Section
				#=======================================================================
				#Set the value to good by default then look for any bad or missing settings
				$TLS12Enforced = $True
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server").DisabledByDefault
					IF ($Enabled -ne 0 -or $DisabledByDefault -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client").DisabledByDefault
					IF ($Enabled -ne 1 -or $DisabledByDefault -ne 0)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server")
				{
					$Enabled = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server").Enabled
					$DisabledByDefault = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server").DisabledByDefault
					IF ($Enabled -ne 1 -or $DisabledByDefault -ne 0)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319")
				{
					$SchUseStrongCrypto = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319").SchUseStrongCrypto
					IF ($SchUseStrongCrypto -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				
				IF (Test-Path "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319")
				{
					$SchUseStrongCrypto = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319").SchUseStrongCrypto
					IF ($SchUseStrongCrypto -ne 1)
					{
						$TLS12Enforced = $False
					}
				}
				ELSE
				{
					$TLS12Enforced = $False
				}
				$WorkflowCount = $null
				$WorkflowCount = (((Get-Counter -Counter '\Health Service\Workflow Count' -SampleInterval 5 -MaxSamples 5).CounterSamples).CookedValue | Measure-Object -Average).Average
				#=======================================================================
				$setupOutputRemote = @()
				if ($UI_info)
				{
					$setupOutputRemote += [pscustomobject]@{
						'Computer Name'		     = $env:COMPUTERNAME
						'Workflow Count'		 = $WorkflowCount
						'IP Address'			 = $IPList
						'OS Version'			 = $OSVersion
						'Management Server Port' = $setuplocationRemote.ManagementServerPort
						'Product'			     = $setuplocationRemote.Product
						'Installed On'		     = $setuplocationRemote.InstalledOn
						'Current Version (Registry)' = $setuplocationRemote.CurrentVersion
						'Server Version (Registry)' = $RemoteServerVersionSwitchOut
						'               (DLL)'   = $ServerVersionDLL
						'UI Version (Registry)'  = $setuplocationRemote.UIVersion
						'           (DLL)'	     = $UIVersionDLL
					}
				}
				else
				{
					$setupOutputRemote += [pscustomobject]@{
						'Computer Name'		     = $env:COMPUTERNAME
						'Workflow Count'		 = $WorkflowCount
						'IP Address'			 = $IPList
						'OS Version'			 = $OSVersion
						'Management Server Port' = $setuplocationRemote.ManagementServerPort
						'Product'			     = $setuplocationRemote.Product
						'Installed On'		     = $setuplocationRemote.InstalledOn
						'Current Version (Registry)' = $setuplocationRemote.CurrentVersion
						'Server Version (Registry)' = $RemoteServerVersionSwitchOut
						'               (DLL)'   = $ServerVersionDLL
					}
				}
				if ($WebConsole_info)
				{
					$setupOutputRemote += [pscustomobject]@{ 'Web Console Version' = $WebConsoleVersionDLL; }
				}
				$setupOutputRemote += [pscustomobject]@{
					'Installation Directory'		  = $installdir
					'Certificate Loaded'			  = $CertLoaded
					'TLS 1.2 Enforced'			      = $TLS12Enforced
					'Last Time Configuration Updated' = $LastUpdatedConfiguration | Get-Date -Format "MMMM dd, yyyy h:mm tt"
					'Current System Time'			  = Get-Date -Format "MMMM dd, yyyy h:mm tt"
					'Powershell Version'			  = $PSVersion
					'CLR Version'					  = $CLRVersion
					'Free Space'					  = $Freespace | Out-String
				}
				if ('7.2.11719.0' -ge $setuplocationRemote.ServerVersion) # SCOM 2016 RTM
				{
					try { $UseMIAPI = (Get-Item 'HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup\UseMIAPI' -ErrorAction Stop | Select-Object Name, Property).Property } # https://docs.microsoft.com/en-us/system-center/scom/whats-new-in-om?view=sc-om-2019#scalability-improvement-with-unix-or-linux-agent-monitoring
					catch [System.Management.Automation.RuntimeException]{ $UseMIAPI = 'Not Set (or Unknown)' }
					$setupOutputRemote | Add-Member -MemberType NoteProperty -Name "UseMIAPI Registry" -Value $UseMIAPI
					#$setupOutputRemote += [pscustomobject]@{ 'UseMIAPI Registry' = $UseMIAPI; }
				}
				$setupOutputRemote += [pscustomobject]@{ 'Services' = $localServices; }
				return $setupOutputRemote
			} | Select-Object -Property * -ExcludeProperty PSComputerName, RunspaceID
			"================================ `
=---- General  Information ----= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
			$setupOutputRemote | Out-File -FilePath "$OutputPath\General Information.txt" -Append
		}
	}
	
	"================================ `
=---- Database Information ----= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	$dbOutput | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	"================================ `
=----- Installed Updates  -----= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	$UpdatesOutput = foreach ($Server in $Servers) { Write-Host "-" -NoNewline -ForegroundColor Green; Invoke-Command -ComputerName $Server -ScriptBlock { Get-HotFix } }
	$UpdatesOutput | Sort InstalledOn, PSComputerName -Descending | Add-Member -MemberType AliasProperty -Name 'Computer Name' -Value PSComputerName -PassThru | Select-Object -Property 'Computer Name', Description, HotFixID, InstalledBy, InstalledOn, Caption | Format-Table * | Out-String -Width 4096 | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	"======================================= `
=-- ConfigService.config File Check --= `
=======================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	foreach ($server in $ManagementServers)
	{
		try
		{
			Write-Host "-" -NoNewline -ForegroundColor Green
			if ($server -ne $Comp)
			{
				$remoteInstallLocation = (Invoke-Command -ComputerName $server -ScriptBlock { get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup" }).InstallDirectory
				$compare = Compare-Object -ReferenceObject (Get-Content -Path "$location`ConfigService.config") -DifferenceObject (Get-Content -Path "$remoteInstallLocation`ConfigService.config") -ErrorAction Stop
				if ($compare)
				{
					Write-Output "There are differences between : $server <-> $env:ComputerName" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
				else
				{
					Write-Output "Configuration Matches between : $server <-> $env:ComputerName" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
			}
			else
			{
				Write-Output "No need to compare this Management Server ($server), we are only comparing this Management Server ($server) against others when needed." | Out-File -FilePath "$OutputPath\General Information.txt" -Append
			}
		}
		catch
		{
			Write-Warning $_
		}
	}
	" " | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	"================================ `
=------ Clock Sync Check ------= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	foreach ($server in $TLSservers)
	{
		try
		{
			Write-Host "-" -NoNewline -ForegroundColor Green
			if ($server -ne $Comp)
			{
				$remoteTime = Invoke-Command -ComputerName $Server { return [System.DateTime]::UtcNow }
				$localTime = [System.DateTime]::UtcNow
				if ($remoteTime.Hour -match $localtime.Hour)
				{
					if ($remoteTime.Minute -match $localtime.Minute)
					{
						Write-Output "Time synchronized between : $server <-> $Comp" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
					}
				}
				
				else
				{
					Write-Output "Time NOT synchronized between : $server <-> $Comp : Remote Time: $remoteTime - Local Time: $localTime" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
			}
		}
		catch { Write-Warning $_ }
	}
	#Check Registry Keys for HKLM:\SYSTEM\CurrentControlSet\services\HealthService
	New-Item -ItemType Directory -Path "$OutputPath\Management Server Config\HealthService Registry" -ErrorAction Stop
	foreach ($server in $ManagementServers)
	{
		try
		{
			Write-Host "-" -NoNewline -ForegroundColor Green
			if ($server -ne $Comp)
			{
				$remoteHealthService = Invoke-Command -ComputerName $Server { return ((Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\services\HealthService -Recurse | Get-ItemProperty | Select-Object * -ExcludeProperty PSParentPath, PSChildName, PSProvider, PSDrive | Out-String -Width 4096).Replace("Microsoft.PowerShell.Core\Registry::", "").Replace('PSPath', "Registry Path")) }
				$remoteHealthService | Out-File -FilePath "$OutputPath\Management Server Config\HealthService Registry\$server.txt"
			}
			else
			{
				$localHealthService = ((Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\services\HealthService -Recurse | Get-ItemProperty | Select-Object * -ExcludeProperty PSParentPath, PSChildName, PSProvider, PSDrive | Out-String -Width 4096).Replace("Microsoft.PowerShell.Core\Registry::", "").Replace('PSPath', "Registry Path"))
				$localHealthService | Out-File -FilePath "$OutputPath\\Management Server Config\HealthService Registry\$Comp.txt"
			}
		}
		catch { Write-Warning $_ }
	}
	" " | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	"================================ `
=------- Latency Check --------= `
================================" | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	$OpsDBServer = $global:OpsDB_SQLServer
	$DWDBServer = $global:DW_SQLServer
	foreach ($ms in $ManagementServers) #Go Through each Management Server
	{
		$pingoutput = @()
		if ($ms -ne $Comp) #If not equal local
		{
			if ($OpsDBServer -ne $DWDBServer) #If OpsDB and DW are not the same run the below
			{
				Invoke-Command -ComputerName $ms -ScriptBlock {
					$dataoutput = @()
					try
					{
						$test = @()
						$test = (Test-Connection -ComputerName $using:OpsDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
						$response = @()
						$response = ($test -as [int])
						$innerdata = @()
						[string]$innerdata = "$using:ms -> $using:OpsDBServer : $response ms"
						$dataoutput += $innerdata
					}
					catch
					{
						Write-Warning $_
						continue
					}
					try
					{
						$test = @()
						$test = (Test-Connection -ComputerName $using:DWDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
						$response = @()
						$response = ($test -as [int])
						$innerdata = @()
						[string]$innerdata = "$using:ms -> $using:DWDBServer : $response ms"
						$dataoutput += $innerdata
					}
					catch
					{
						Write-Warning $_
						continue
					}
					return $dataoutput
				} | Out-File -FilePath "$OutputPath\General Information.txt" -Append #end invoke
			} #end if
			else #Else run the below
			{
				try{Invoke-Command -ComputerName $ms -ScriptBlock {
					$pingoutput = @()
					try
					{
						$test = @()
						$test = (Test-Connection -ComputerName $using:OpsDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
						$response = @()
						$response = ($test -as [int])
						$innerdata = @()
						[string]$innerdata = "$using:ms -> $using:OpsDBServer : $response ms"
					}
					catch
					{
						Write-Warning $_
						continue
					}
					return $innerdata
				} | Out-File -FilePath "$OutputPath\General Information.txt" -Append #end invoke
				} catch { continue }
			} #end else
		} #end If not equal local
		else #Local Execution
		{
			if ($OpsDBServer -ne $DWDBServer)
			{
				try
				{
					$test = @()
					$test = (Test-Connection -ComputerName $OpsDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
					$response = @()
					$response = ($test -as [int])
					$innerdata = @()
					[string]$innerdata = "$server -> $OpsDBServer : $response ms"
					$innerdata | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
				catch
				{
					Write-Warning $_
					continue
				}
				try
				{
					$test = @()
					$test = (Test-Connection -ComputerName $DWDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
					$response = @()
					$response = ($test -as [int])
					$innerdata = @()
					[string]$innerdata = "$server -> $DWDBServer : $response ms"
					$innerdata | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
				catch
				{
					Write-Warning $_
					continue
				}
			}
			else
			{
				try
				{
					$test = @()
					$test = (Test-Connection -ComputerName $OpsDBServer -Count 4 | measure-Object -Property ResponseTime -Average).average
					$response = @()
					$response = ($test -as [int])
					$innerdata = @()
					[string]$innerdata = "$server -> $OpsDBServer : $response ms"
					$innerdata | Out-File -FilePath "$OutputPath\General Information.txt" -Append
				}
				catch
				{
					Write-Warning $_
					continue
				}
			}
		}
	}
	if ($pingall)
	{
		foreach ($server in $TestedTLSservers)
		{
			Invoke-Command -ComputerName $server -ScriptBlock {
				#Start Checking for Connectivity to Management Servers in MG
				$pingoutput = @()
				foreach ($ms in $using:ManagementServers)
				{
					if ($ms -eq $using:server) { continue }
					try
					{
						$test = @()
						$test = (Test-Connection -ComputerName $ms -Count 4 | measure-Object -Property ResponseTime -Average).average
						$response = @()
						$response = ($test -as [int])
						$innerdata = @()
						[string]$innerdata = "$using:server -> $ms : $response ms"
					}
					catch
					{
						Write-Warning $_
						continue
					}
				}
				return $innerdata
			} | Out-File -FilePath "$OutputPath\General Information.txt" -Append
		}
	}
	$pingoutput | Out-File -FilePath "$OutputPath\General Information.txt" -Append
	
	# ==================================================================================
	$mgOverviewImport = Import-Csv "$OutputPath`\MG_Overview.csv"
	
	$mgOverviewImport | % {
		$MGName = $_.MG_Name
		$MSCount = $_.MS_Count
		$GWCount = $_.GW_Count
		$AgentCount = $_.Agent_Count
		$AgentPending = $_.Agent_Pending
		$UnixCount = $_.Unix_Count
		$NetworkDeviceCount = $_.NetworkDevice_Count
		$NoteInfo = ([pscustomobject]@{
				"`tManagement Group Name" = $MGName
				"`tGateway Count"		  = $GWCount
				"`tAgent Count"		      = $AgentCount
				"`tAgent Pending"		  = $AgentPending
				"`tUnix Count"		      = $UnixCount
				"`tNetwork Device Count"  = $NetworkDeviceCount
				"`tEnvironment Type"	  = '(Prod / Non-Prod or Dev)'
			} | Out-String -Width 4096).Replace("`r", "")
	}
	$NoteUpdate = @"
Environment:

    SCOM Version: $ServerVersionDLL
    MS Server Version: $OSVersion
    Number of MS: $MSCount
    SQL Info: $OMSQLProperties
    Environment: 
         $NoteInfo
"@
	$NoteUpdate | Out-File -FilePath "$OutputPath\note.txt"
}
