Function Get-TLSRegistryKeys
{
	[CmdletBinding()]
	Param
	(
		[string[]]$Servers
	)
	Write-Host "  Accessing Registry on:`n" -NoNewline -ForegroundColor Gray
	foreach ($server in $servers)
	{
		Write-Host "     $server" -NoNewline -ForegroundColor Cyan
		if ($server -notcontains $env:COMPUTERNAME)
		{
			Invoke-Command -ComputerName $server {
				Write-Host "-" -NoNewline -ForegroundColor Green
				$finalData = @()
				$LHost = $env:computername
				$ProtocolList = "TLS 1.0", "TLS 1.1", "TLS 1.2"
				$ProtocolSubKeyList = "Client", "Server"
				$DisabledByDefault = "DisabledByDefault"
				$Enabled = "Enabled"
				$registryPath = "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\"
				$CrypKey1 = "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319"
				$CrypKey2 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319"
				$Strong = "SchUseStrongCrypto"
				$Crypt1 = (Get-ItemProperty -Path $CrypKey1 -Name $Strong -ea 0).SchUseStrongCrypto
				If ($crypt1 -eq 1)
				{
					$Crypt1 = $true
				}
				else
				{
					$Crypt1 = $False
				}
				$crypt2 = (Get-ItemProperty -Path $CrypKey2 -Name $Strong -ea 0).SchUseStrongCrypto
				if ($crypt2 -eq 1)
				{
					$Crypt2 = $true
				}
				else
				{
					$Crypt2 = $False
				}
				##  ODBC : https://www.microsoft.com/en-us/download/details.aspx?id=50420
				##  OLEDB : https://docs.microsoft.com/en-us/sql/connect/oledb/download-oledb-driver-for-sql-server?view=sql-server-ver15
				[string[]]$data = (Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*sql*" }).name
				$odbc = $data | where { $_ -like "Microsoft ODBC Driver *" } # Need to validate version
				if ($odbc -match "11|13") { Write-Host "FOUND $odbc" }
				if ($odbc)
				{
					$ODBC = $true
				}
				else
				{
					$ODBC = $False
				}
				$oledb = $data | where { $_ -eq 'Microsoft OLE DB Driver for SQL Server' }
				if ($oledb)
				{
					$OLEDB = $true
				}
				else
				{
					$OLEDB = $False
				}
				foreach ($Protocol in $ProtocolList)
				{
					foreach ($key in $ProtocolSubKeyList)
					{
						#Write-Host "Checking for $protocol\$key"
						$currentRegPath = $registryPath + $Protocol + "\" + $key
						$IsDisabledByDefault = @()
						$IsEnabled = @()
						$localresults = @()
						if (!(Test-Path $currentRegPath))
						{
							$IsDisabledByDefault = "Null"
							$IsEnabled = "Null"
						}
						else
						{
							$IsDisabledByDefault = (Get-ItemProperty -Path $currentRegPath -Name $DisabledByDefault -ea 0).DisabledByDefault
							if ($IsDisabledByDefault -eq 4294967295)
							{
								$IsDisabledByDefault = "0xffffffff"
							}
							if ($IsDisabledByDefault -eq $null)
							{
								$IsDisabledByDefault = "DoesntExist"
							}
							$IsEnabled = (Get-ItemProperty -Path $currentRegPath -Name $Enabled -ea 0).Enabled
							if ($IsEnabled -eq 4294967295)
							{
								$isEnabled = "0xffffffff"
							}
							if ($IsEnabled -eq $null)
							{
								$IsEnabled = "DoesntExist"
							}
						}
						$localresults = "PipeLineKickStart" | select @{ n = 'Server'; e = { $LHost } },
																	 @{ n = 'Protocol'; e = { $Protocol } },
																	 @{ n = 'Type'; e = { $key } },
																	 @{ n = 'DisabledByDefault'; e = { $IsDisabledByDefault } },
																	 @{ n = 'IsEnabled'; e = { $IsEnabled } }
						$finalData += $localresults
					}
				}
				$finalData | ft -AutoSize
				'' | Select @{ n = 'StrongCryptoMS'; e = { $Crypt1 } },
							@{ n = 'StrongCryptoWOW'; e = { $Crypt2 } },
							@{ n = 'OLEDB'; e = { $OLEDB } },
							@{ n = 'ODBC'; e = { $odbc } }
			}
		}
		else
		{
			Write-Host "-" -NoNewline -ForegroundColor Green
			$finalData = @()
			$LHost = $env:computername
			$ProtocolList = "TLS 1.0", "TLS 1.1", "TLS 1.2"
			$ProtocolSubKeyList = "Client", "Server"
			$DisabledByDefault = "DisabledByDefault"
			$Enabled = "Enabled"
			$registryPath = "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\"
			$CrypKey1 = "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319"
			$CrypKey2 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319"
			$Strong = "SchUseStrongCrypto"
			$Crypt1 = (Get-ItemProperty -Path $CrypKey1 -Name $Strong -ea 0).SchUseStrongCrypto
			If ($crypt1 -eq 1)
			{
				$Crypt1 = $true
			}
			else
			{
				$Crypt1 = $False
			}
			$crypt2 = (Get-ItemProperty -Path $CrypKey2 -Name $Strong -ea 0).SchUseStrongCrypto
			if ($crypt2 -eq 1)
			{
				$Crypt2 = $true
			}
			else
			{
				$Crypt2 = $False
			}
			##  ODBC : https://www.microsoft.com/en-us/download/details.aspx?id=50420
			##  OLEDB : https://docs.microsoft.com/en-us/sql/connect/oledb/download-oledb-driver-for-sql-server?view=sql-server-ver15
			[string[]]$data = (Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*sql*" }).name
			$odbc = $data | where { $_ -like "Microsoft ODBC Driver *" } # Need to validate version
			if ($odbc -match "11|13") { Write-Host "FOUND $odbc" }
			if ($odbc)
			{
				$ODBC = $true
			}
			else
			{
				$ODBC = $False
			}
			$oledb = $data | where { $_ -eq 'Microsoft OLE DB Driver for SQL Server' }
			if ($oledb)
			{
				$OLEDB = $true
			}
			else
			{
				$OLEDB = $False
			}
			foreach ($Protocol in $ProtocolList)
			{
				foreach ($key in $ProtocolSubKeyList)
				{
					#Write-Host "Checking for $protocol\$key"
					$currentRegPath = $registryPath + $Protocol + "\" + $key
					$IsDisabledByDefault = @()
					$IsEnabled = @()
					$localresults = @()
					if (!(Test-Path $currentRegPath))
					{
						$IsDisabledByDefault = "Null"
						$IsEnabled = "Null"
					}
					else
					{
						$IsDisabledByDefault = (Get-ItemProperty -Path $currentRegPath -Name $DisabledByDefault -ea 0).DisabledByDefault
						if ($IsDisabledByDefault -eq 4294967295)
						{
							$IsDisabledByDefault = "0xffffffff"
						}
						if ($IsDisabledByDefault -eq $null)
						{
							$IsDisabledByDefault = "DoesntExist"
						}
						$IsEnabled = (Get-ItemProperty -Path $currentRegPath -Name $Enabled -ea 0).Enabled
						if ($IsEnabled -eq 4294967295)
						{
							$isEnabled = "0xffffffff"
						}
						if ($IsEnabled -eq $null)
						{
							$IsEnabled = "DoesntExist"
						}
					}
					$localresults = "PipeLineKickStart" | select @{ n = 'Server'; e = { $LHost } },
																 @{ n = 'Protocol'; e = { $Protocol } },
																 @{ n = 'Type'; e = { $key } },
																 @{ n = 'DisabledByDefault'; e = { $IsDisabledByDefault } },
																 @{ n = 'IsEnabled'; e = { $IsEnabled } }
					$finalData += $localresults
				}
			}
			$finalData | ft -AutoSize
			'' | Select @{ n = 'StrongCryptoMS'; e = { $Crypt1 } },
						@{ n = 'StrongCryptoWOW'; e = { $Crypt2 } },
						@{ n = 'OLEDB'; e = { $OLEDB } },
						@{ n = 'ODBC'; e = { $odbc } }
		}
		
		Write-Host "> Completed!`n" -NoNewline -ForegroundColor Green
	}
}