#Variables Section
$UnixHostname = '<hostname>' # <---- FQDN Here
$SSH_Port = '22' # <---- SSH Port Number Here
$UnixUsername = '<root_user>' # <---- Root Account Here
$UnixPassword = $null # <---- If you are comfortable inserting password in script, do so here. Otherwise, leave this $null
$SCOM_MonitoringUsername = '<unix_monitoring_acct>'
$WindowsPath_for_Temp = 'C:\Temp' # <----- Where to store OMI / SCX Logs as well as Certificate
$KerberosAuthentication = $false
$Directory_for_Plink = 'C:\Scripts' # <----- Location of Plink ----- Script will auto detect if you have plink installed in Program Files or Program Files (x86), so if PuTTY or plink is already installed, you can safely ignore this value.
$Script_Output = 'C:\Temp'

#------------------------------


if (!($UnixPassword))
{
	try { $creds = Get-Credential -Credential $UnixUsername -ErrorAction Stop }
	catch { break }
}
else
{
	$CredentialPassword = ConvertTo-SecureString $UnixPassword -AsPlainText -Force
}


$puttypathx86 = Resolve-Path "${env:ProgramFiles(x86)}\PuTTY\plink.exe" -ErrorAction SilentlyContinue
$puttypath = Resolve-Path "${env:ProgramFiles}\PuTTY\plink.exe" -ErrorAction SilentlyContinue
if ($puttypathx86)
{
	Push-Location ${env:ProgramFiles(x86)}\PuTTY\
}
elseif ($puttypath)
{
	Push-Location ${env:ProgramFiles}\PuTTY\
}
else
{
	Push-Location $Directory_for_Plink # <----- Location of Plink
}

#cd C:\Scripts
if (!$CredentialPassword)
{
	$Credential = New-Object System.Management.Automation.PSCredential ($UnixUsername, $creds.Password)
}
else
{
	$Credential = New-Object System.Management.Automation.PSCredential ($UnixUsername, $CredentialPassword)
}

if (!$UnixPassword)
{
	$UnixPassword = $Credential.GetNetworkCredential().Password
}


$networkTest_SSH = $null
$networkTest_WSMAN = $null
$ssh_Logs = $null
$ssh_isactive = $null
$rpm_qa = $null
$rpm_qa_scom = $null
$rpm_qa_original = $null
$UnixDNSHostname = $null
$existing_pathsfound = $null
$firewalld_isactive = $null
$firewalld_configuration = $null
$scxadmin_status = $null
$linux_openssl_ciphers = $null
$omi_scx_os = $null
$WinRM_test = $null
$sftp_output = $null
$sftp_enabled = $null
$uname_a = $null
$override_present = $null
$scx_release_present = $null
$iptables_configured = $null
$script_out = $null

function Main-Script
{
	param
	(
		[Parameter(Mandatory = $true)]
		[string]$ConnectionType
	)
	$networkTest_SSH = (Test-NetConnection -ComputerName $UnixHostname -Port $SSH_Port -ErrorAction SilentlyContinue -InformationLevel Quiet)
	$networkTest_WSMAN = (Test-NetConnection -ComputerName $UnixHostname -Port 1270 -ErrorAction SilentlyContinue -InformationLevel Quiet)
	if ($ConnectionType -eq 'Kerberos')
	{
		$WinRM_test = try { Get-WSManInstance -OptionSet @{ SkipCACheck = 1 } -ResourceURI 'http://schemas.microsoft.com/wbem/wscim/1/cim-schema/2/SCX_Agent?__cimnamespace=root/scx' -ConnectionURI "https://$UnixHostname`:1270/wsman" -Verbose -Authentication Kerberos -Enumerate }
		catch { $WinRM_testError = $_ }
		Write-Output 'y' | .\plink.exe $UnixHostname -A -P $SSH_Port 'echo'
		$sftp_output = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'cat /etc/ssh/sshd_config | grep sftp')
		if ($sftp_output[0] -ne '#')
		{
			$sftp_enabled = $sftp_output.contains('sftp')
		}
		else
		{
			$sftp_enabled = $false
		}
		$omi_scx_os = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port '/opt/omi/bin/omicli ei root/scx scx_operatingsystem')
		$uname_a = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'uname -a')
		$override_present = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port '[[ -f /etc/opt/microsoft/scx/conf/disablereleasefileupdates ]] && cat /etc/opt/microsoft/scx/conf/disablereleasefileupdates')
		$scx_release_present = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port '[[ -f /etc/opt/microsoft/scx/conf/scx-release ]] && cat /etc/opt/microsoft/scx/conf/scx-release')
		$rpm_qa_original = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'rpm -qa')
		$rpm_qa = $rpm_qa_original | Where { ($_ -like "glibc*") -or ($_ -like "openssl*") -or ($_ -like "pam*") } | sort
		$rpm_qa_scom = $rpm_qa_original | Where { ($_ -like "scx*") -or ($_ -like "omi*") } | sort
		$iptables_configured = (Write-Output `r | .\plink.exe $UnixHostname -A -P $SSH_Port '[[ -f /etc/sysconfig/iptables ]] && echo "true"  ||  echo "false"')
		$firewalld_isactive = (Write-Output `r | .\plink.exe $UnixHostname -A -P $SSH_Port "systemctl is-active firewalld")
		$firewalld_configuration = (Write-Output `r | .\plink.exe $UnixHostname -A -P $SSH_Port "firewall-cmd --list-all")
		$scxadmin_status = (Write-Output '`r' | .\plink.exe $UnixHostname -A -P $SSH_Port "/usr/sbin/scxadmin -status")
		$existing_pathsfound = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port '[[ -d /var/opt/omi ]] && echo "/var/opt/omi :: was found in your filesystem.";[[ -d /var/opt/microsoft/scx ]] && echo "/var/opt/microsoft/scx :: was found in your filesystem.";[[ -d /opt/microsoft/scx/ ]] && echo "/opt/microsoft/scx/ :: was found in your filesystem.";[[ -d /opt/omi ]] && echo "/opt/omi :: was found in your filesystem.";[[ -d /etc/opt/microsoft ]] && echo "/etc/opt/microsoft :: was found in your filesystem.";[[ -d /etc/opt/omi ]] && echo "/etc/opt/omi :: was found in your filesystem.";[[ -f /etc/pam.d/omi ]] && echo "/etc/pam.d/omi :: was found in your filesystem."  ||  echo "/etc/pam.d/omi :: was NOT found in your filesystem."')
		#Certificates
		$linux_openssl = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'openssl x509 -in /etc/opt/omi/ssl/omi.pem -text -noout')
		$linux_openssl_ciphers = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'openssl ciphers -V')
		$linux_certificate = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port 'cat /etc/opt/omi/ssl/omi.pem')
		$WindowsPath_for_Temp = Try { Resolve-Path $WindowsPath_for_Temp -ErrorAction Stop }
		Catch { Write-Warning $_; Break }
		$linux_certificate | Out-File -FilePath "$WindowsPath_for_Temp`\SCOM`_$UnixHostname`_UnixCertificate.cer" -Encoding default
		# End Certificates
		#Sudo Check
		$sudo_scomacct = (Write-Output 'n' | .\plink.exe $UnixHostname -A -P $SSH_Port "sudo -l -U $SCOM_MonitoringUsername")
		#End Sudo Check
		$OSOutput = (Write-Output '`r' | .\plink.exe $UnixHostname -A -P $SSH_Port "egrep '^(VERSION|NAME)=' /etc/os-release").Replace("`"", "").Replace("NAME=", "").Replace("VERSION=", "")
		if ($iptables_configured)
		{
			$iptables = (Write-Output `r | .\plink.exe $UnixHostname -A -P $SSH_Port "iptables --list | grep 1270")
		}
		else
		{
			$iptables = "IP Table is not being used."
		}
	}
	elseif ($ConnectionType -eq 'Basic')
	{
		$WinRM_test = try { Get-WSManInstance -OptionSet @{ SkipCACheck = 1 } -ResourceURI 'http://schemas.microsoft.com/wbem/wscim/1/cim-schema/2/SCX_Agent?__cimnamespace=root/scx' -Credential $Credential -ConnectionURI "https://$UnixHostname`:1270/wsman" -Verbose -Authentication Basic -Enumerate }
		catch { $WinRM_testError = $_ }
		Write-Output 'y' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'echo'
		$sftp_output = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'cat /etc/ssh/sshd_config | grep sftp')
		if ($sftp_output[0] -ne '#')
		{
			$sftp_enabled = $sftp_output.contains('sftp')
		}
		else
		{
			$sftp_enabled = $false
		}
		$omi_scx_os = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port '/opt/omi/bin/omicli ei root/scx scx_operatingsystem')
		$uname_a = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'uname -a')
		$override_present = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port '[[ -f /etc/opt/microsoft/scx/conf/disablereleasefileupdates ]] && cat /etc/opt/microsoft/scx/conf/disablereleasefileupdates')
		$scx_release_present = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port '[[ -f /etc/opt/microsoft/scx/conf/scx-release ]] && cat /etc/opt/microsoft/scx/conf/scx-release')
		$rpm_qa_original = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'rpm -qa')
		$rpm_qa = $rpm_qa_original | Where { ($_ -like "glibc*") -or ($_ -like "openssl*") -or ($_ -like "pam*") } | sort
		$rpm_qa_scom = $rpm_qa_original | Where { ($_ -like "scx*") -or ($_ -like "omi*") } | sort
		$iptables_configured = (Write-Output `r | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port '[[ -f /etc/sysconfig/iptables ]] && echo "true"  ||  echo "false"')
		$firewalld_isactive = (Write-Output `r | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "systemctl is-active firewalld")
		$firewalld_configuration = (Write-Output `r | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "firewall-cmd --list-all")
		$scxadmin_status = (Write-Output '`r' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "/usr/sbin/scxadmin -status")
		$existing_pathsfound = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port '[[ -d /var/opt/omi ]] && echo "/var/opt/omi :: was found in your filesystem.";[[ -d /var/opt/microsoft/scx ]] && echo "/var/opt/microsoft/scx :: was found in your filesystem.";[[ -d /opt/microsoft/scx/ ]] && echo "/opt/microsoft/scx/ :: was found in your filesystem.";[[ -d /opt/omi ]] && echo "/opt/omi :: was found in your filesystem.";[[ -d /etc/opt/microsoft ]] && echo "/etc/opt/microsoft :: was found in your filesystem.";[[ -d /etc/opt/omi ]] && echo "/etc/opt/omi :: was found in your filesystem.";[[ -f /etc/pam.d/omi ]] && echo "/etc/pam.d/omi :: was found in your filesystem."  ||  echo "/etc/pam.d/omi :: was NOT found in your filesystem."')
		#Certificates
		$linux_openssl = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'openssl x509 -in /etc/opt/omi/ssl/omi.pem -text -noout')
		$linux_openssl_ciphers = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'openssl ciphers -V')
		$linux_certificate = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port 'cat /etc/opt/omi/ssl/omi.pem')
		$WindowsPath_for_Temp = Try { Resolve-Path $WindowsPath_for_Temp -ErrorAction Stop }
		Catch { Write-Warning $_; Break }
		$linux_certificate | Out-File -FilePath "$WindowsPath_for_Temp`\SCOM`_$UnixHostname`_UnixCertificate.cer" -Encoding default
		# End Certificates
		#Sudo Check
		$sudo_scomacct = (Write-Output 'n' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "sudo -l -U $SCOM_MonitoringUsername")
		#End Sudo Check
		$OSOutput = (Write-Output '`r' | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "egrep '^(VERSION|NAME)=' /etc/os-release").Replace("`"", "").Replace("NAME=", "").Replace("VERSION=", "")
		if ($iptables_configured)
		{
			$iptables = (Write-Output `r | .\plink.exe $UnixHostname -l $UnixUsername -pw $UnixPassword -P $SSH_Port "iptables --list | grep 1270")
		}
		else
		{
			$iptables = "IP Table is not being used."
		}
	}
	if ($Script_Output)
	{
		$script_out += "
=====================
Operating System
=====================
"
		$script_out += $OSOutput[0] + " " + $OSOutput[1]
	}
	Write-Host "`n=====================`nOperating System`n=====================" -ForegroundColor Cyan
	$OSOutput[0] + " " + $OSOutput[1]
	#(Write-Output '`r' | .\plink.exe $UnixHostname $ConnectionArguments "cat /etc/*-release") | Select -Last 1
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Agent OS Override File
=====================
"
		if ($override_present) { $script_out += $override_present }
		else { $script_out += "Override File is not present." }
	}
	Write-Host "`n=====================`nAgent OS Override File`n=====================" -ForegroundColor Cyan
	if ($override_present) { $override_present }
	else { Write-Host "Override File is not present." }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
SCX / OMI Service Status
=====================
"
		if ($scxadmin_status) { $script_out += $scxadmin_status }
		else { $script_out += "Unable to run:`n`tscxadmin -status" }
	}
	Write-Host "`n=====================`nSCX / OMI Service Status`n=====================" -ForegroundColor Cyan
	if ($scxadmin_status) { $scxadmin_status }
	else { Write-Warning "Unable to run:`n`tscxadmin -status" }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Unix Reverse Lookup (DNS)
=====================
"
		$UnixDNSHostname = [System.Net.DNS]::GetHostByName($UnixHostname)
		$script_out += $UnixDNSHostname.Hostname
	}
	Write-Host "`n=====================`nUnix Reverse Lookup (DNS)`n=====================" -ForegroundColor Cyan
	$UnixDNSHostname = [System.Net.DNS]::GetHostByName($UnixHostname)
	$UnixDNSHostname.Hostname
	
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Unix Forward Lookup (DNS)
=====================
"
		$script_out += ([System.Net.DNS]::GetHostByAddress(($UnixDNSHostname.AddressList).IPAddressToString)).AddressList.IPAddressToString
	}
	Write-Host "`n=====================`nUnix Forward Lookup (DNS)`n=====================" -ForegroundColor Cyan
	([System.Net.DNS]::GetHostByAddress(($UnixDNSHostname.AddressList).IPAddressToString)).AddressList.IPAddressToString
	
	if ($Script_Output)
	{
		$script_out += "

=====================
SFTP Enabled
=====================
"
		if ($sftp_enabled) { $script_out += $sftp_enabled }
		else { $script_out += 'Unable to detect SFTP status' }
	}
	Write-Host "`n=====================`nSFTP Enabled`n=====================" -ForegroundColor Cyan
	if ($sftp_enabled) { $sftp_enabled }
	else { Write-Host 'Unable to detect SFTP status' }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
SSH Network Test ($SSH_Port)
=====================
"
		$script_out += $networkTest_SSH
	}
	Write-Host "`n=====================`nSSH Network Test ($SSH_Port)`n=====================" -ForegroundColor Cyan
	$networkTest_SSH
	
	if ($Script_Output)
	{
		$script_out += "

=====================
WSMan Network Test (1270)
=====================
"
		$script_out += ($networkTest_WSMAN | Out-String).Trim()
	}
	Write-Host "`n=====================`nWSMan Network Test (1270)`n=====================" -ForegroundColor Cyan
	($networkTest_WSMAN | Out-String).Trim()
	
	if ($Script_Output)
	{
		$script_out += "

=====================
WinRM Enumerate Check
=====================
"
		if ($WinRM_test) { $script_out += $WinRM_test }
		else { $script_out += "Failure Detected:`n`t$WinRM_testError" }
	}
	Write-Host "`n=====================`nWinRM Enumerate Check`n=====================" -ForegroundColor Cyan
	if ($WinRM_test) { $WinRM_test }
	else { Write-Host "Failure Detected:`n`t$WinRM_testError" -ForegroundColor Red }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Ip Tables (1270)
=====================
"
		if ($iptables) { $script_out += $iptables }
		else
		{
			$script_out += "No Exclusion found for Port 1270.
Try this command (replacing <ip_address> with Management Server IP and <prefix_length>):
	iptables -I INPUT 1 -p tcp -s <ip_address>/<prefix_length> --dport 1270 -m state --state NEW,ESTABLISHED -j ACCEPT'"
		}
		
	}
	Write-Host "`n=====================`nIp Tables (1270)`n=====================" -ForegroundColor Cyan
	if ($iptables) { $iptables }
	else { Write-Host "No Exclusion found for Port 1270.`n  Try this command (replacing <ip_address> with Management Server IP and <prefix_length>):`n`tiptables -I INPUT 1 -p tcp -s <ip_address>/<prefix_length> --dport 1270 -m state --state NEW,ESTABLISHED -j ACCEPT'" }
	
	if ($Script_Output)
	{
		$script_out += "
		
=====================
firewalld Service Status
=====================
"
		if ($firewalld_isactive) { $script_out += $firewalld_isactive }
		else { $script_out += "firewalld was not found" }
	}
	Write-Host "`n=====================`nfirewalld Service Status`n=====================" -ForegroundColor Cyan
	if ($firewalld_isactive) { $firewalld_isactive }
	else { Write-Host "firewalld was not found" }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
firewalld Configuration
=====================
"
		if ($firewalld_configuration) { $script_out += $firewalld_configuration }
		else { $script_out += "firewalld is not installed, or you do not have permission to view this data." }
	}
	Write-Host "`n=====================`nfirewalld Configuration`n=====================" -ForegroundColor Cyan
	if ($firewalld_configuration) { $firewalld_configuration }
	else { Write-Host "firewalld is not installed, or you do not have permission to view this data." }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
uname -a Output
=====================
"
		$script_out += $uname_a
	}
	Write-Host "`n=====================`nuname -a Output`n=====================" -ForegroundColor Cyan
	$uname_a
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Prerequisites Installed
=====================
"
		$script_out += $rpm_qa | Out-String -Width 2048
	}
	Write-Host "`n=====================`nPrerequisites Installed`n=====================" -ForegroundColor Cyan
	$rpm_qa
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Certificate OpenSSL Information
=====================
"
		if ($linux_openssl) { $script_out += $linux_openssl | Out-String -Width 2048; $linux_certificate_passed = $true }
		else { $script_out += "No Certificate Detected in following path: /etc/opt/omi/ssl/omi.pem"; $linux_certificate_passed = $false }
	}
	Write-Host "`n=====================`nCertificate OpenSSL Information`n=====================" -ForegroundColor Cyan
	if ($linux_openssl) { $linux_openssl; $linux_certificate_passed = $true }
	else { Write-Host "No Certificate Detected in following path: /etc/opt/omi/ssl/omi.pem"; $linux_certificate_passed = $false }
	
	if ($linux_certificate_passed)
	{
		if ($Script_Output)
		{
			$script_out += "

=====================
Certificate OpenSSL - Subject Common Name
=====================
"
			$linux_certificate_cn = ($linux_openssl | Where{ $_ -match 'Subject:' }).Split('CN=')
			if (($linux_certificate_cn[3].Replace(',', '').Trim()) -eq ($linux_certificate_cn[6].Trim()))
			{
				$script_out += $linux_certificate_cn[6].Trim()
			}
			else
			{
				$script_out += $linux_certificate_cn[3].Replace(',', '').Trim() + " and " + $linux_certificate_cn[6].Trim()
			}
		}
		Write-Host "`n=====================`nCertificate OpenSSL - Subject Common Name`n=====================" -ForegroundColor Cyan
		$linux_certificate_cn = ($linux_openssl | Where{ $_ -match 'Subject:' }).Split('CN=')
		if (($linux_certificate_cn[3].Replace(',', '').Trim()) -eq ($linux_certificate_cn[6].Trim()))
		{
			$linux_certificate_cn[6].Trim()
		}
		else
		{
			$linux_certificate_cn[3].Replace(',', '').Trim() + " and " + $linux_certificate_cn[6].Trim()
		}
	}
	
	if ($Script_Output)
	{
		$script_out += "

=====================
OpenSSL Ciphers
=====================
"
		$script_out += $linux_openssl_ciphers | Out-String -Width 2048
	}
	Write-Host "`n=====================`nOpenSSL Ciphers`n=====================" -ForegroundColor Cyan
	$linux_openssl_ciphers
	
	if ($Script_Output)
	{
		$script_out += "

=====================
scx_operatingsystem Node in OMI
=====================
"
		if ($omi_scx_os)
		{
			$script_out += $omi_scx_os | Out-String -Width 2048
		}
		else
		{
			$script_out += 'Could not run the following command: 
	/opt/omi/bin/omicli ei root/scx scx_operatingsystem'
		}
	}
	Write-Host "`n=====================`nscx_operatingsystem Node in OMI`n=====================" -ForegroundColor Cyan
	if ($omi_scx_os)
	{
		$omi_scx_os
	}
	else
	{
		Write-Host 'Could not run the following command: ' -NoNewline -ForegroundColor Yellow
		Write-Host '/opt/omi/bin/omicli ei root/scx scx_operatingsystem' -ForegroundColor Red
	}
	
	if ($Script_Output)
	{
		$script_out += "

=====================
scx-release file
=====================
"
		if ($scx_release_present)
		{
			$script_out += $scx_release_present | Out-String -Width 2048
		}
		else
		{
			$script_out += "scx-release was not found in path: /etc/opt/microsoft/scx/conf/scx-release"
		}
	}
	Write-Host "`n=====================`nscx-release file`n=====================" -ForegroundColor Cyan
	if ($scx_release_present)
	{
		$scx_release_present
	}
	else
	{
		Write-Host "scx-release was not found in path: /etc/opt/microsoft/scx/conf/scx-release"
	}
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Sudo Permissions for SCOM Monitoring Account ($SCOM_MonitoringUsername)
=====================
"
		$script_out += $sudo_scomacct | Out-String -Width 2048
	}
	Write-Host "`n=====================`nSudo Permissions for SCOM Monitoring Account ($SCOM_MonitoringUsername)`n=====================" -ForegroundColor Cyan
	$sudo_scomacct
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Currently Installed Operations Manager Components
=====================
"
		if ($rpm_qa_scom) { $script_out += $rpm_qa_scom | Out-String -Width 2048 }
		else { $script_out += "No Components Detected!" }
	}
	Write-Host "`n=====================`nCurrently Installed Operations Manager Components`n=====================" -ForegroundColor Cyan
	if ($rpm_qa_scom) { $rpm_qa_scom }
	else { Write-Host "No Components Detected!" -ForegroundColor Yellow }
	
	if ($Script_Output)
	{
		$script_out += "

=====================
Existing Operations Manager Paths Found on Unix
=====================
"
		if ($existing_pathsfound) { $script_out += $existing_pathsfound | Out-String -Width 2048 }
		else { $script_out += "Unable to find any Existing Paths." }
		
	}
	Write-Host "`n=====================`nExisting Operations Manager Paths Found on Unix`n=====================" -ForegroundColor Cyan
	if ($existing_pathsfound) { $existing_pathsfound }
	else { Write-Host "Unable to find any Existing Paths." -ForegroundColor Yellow }
	Pop-Location
	if ($Script_Output)
	{
		$script_out | Out-File $Script_Output\Linuxchecker_Output.txt
	}
}


if ($KerberosAuthentication) #Kerberos Authentication
{
	Main-Script -ConnectionType Kerberos
	
}
else #Basic Authentication
{
	Main-Script -ConnectionType Basic
}