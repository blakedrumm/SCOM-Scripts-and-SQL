![Linux Gather](/media/git-guidance/projects/linux-gather.png)

# Linux Data Gathering

This script requires `plink.exe` in the same directory as the script when running.

plink (PuTTY) offical site:
https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html