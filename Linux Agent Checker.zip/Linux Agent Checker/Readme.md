![Linux Gather](/media/git-guidance/projects/linux-gather.png)

# Linux Data Gathering

This script requires `plink.exe`.

plink (PuTTY) offical site:
https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html