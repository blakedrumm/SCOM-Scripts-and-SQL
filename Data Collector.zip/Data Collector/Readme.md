#Instructions

----
Customer extracts collection tool to a directory.

You need to change to the directory in PowerShell to the script location, such as “cd C:\SCOMDataCollector_CustomerVersion”
 
If run on a SCOM management server (preferred) we will gather their SQL server names and DB names from the local registry.  Otherwise user will need to input names.

The script will attempt to query the SQL server remotely, and create CSV files in .\output.  It will also collect Operations Manager/ System/ Application events logs in evtx format with metadata. 

We will query both OperationsManager DB and Master DB in some cases, so having a high level of rights to SQL is preferred.

A zip file will be created in the directory where you are running the script, SDC_Results_04_04_1975.zip