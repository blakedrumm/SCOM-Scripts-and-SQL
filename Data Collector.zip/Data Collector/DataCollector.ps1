﻿<#
	.SYNOPSIS
		This script collects data from your SCOM Environment that can be very helpful in troubleshooting.
	
	.DESCRIPTION
		For full support, please run this script from a Management Server..
	
	.EXAMPLE
				PS C:\> .\DataCollector.ps1 -CheckTLSRegKeys -CheckCertificates -GetEventLogs -MSInfo32 -AssumeYes -ExportMPs -CaseNumber 0123456789
	
	.NOTES
		This script is intended for System Center Operations Manager Environments. This is currently in development by the SCEM Support Team with Microsoft.
#>
[OutputType([string])]
[CmdletBinding()]
param
(
	[Parameter(Mandatory = $false,
			   Position = 1)]
	[switch]$CheckTLSRegKeys,
	[Parameter(Mandatory = $false,
			   Position = 2)]
	[switch]$CheckCertificates,
	[Parameter(Mandatory = $false,
			   Position = 3)]
	[switch]$GetEventLogs,
	[Parameter(Mandatory = $false,
			   Position = 4)]
	[switch]$MSInfo32,
	[Parameter(Mandatory = $false,
			   Position = 5)]
	[switch]$AssumeYes,
	[Parameter(Mandatory = $false,
			   Position = 6)]
	[switch]$ExportMPs,
	[Parameter(Mandatory = $false,
			   Position = 7)]
	[string]$CaseNumber
	
)

$scriptout = [Array] @()
[String]$Comp = Resolve-DnsName $env:COMPUTERNAME -Type A | Select-Object -Property Name -ExpandProperty Name
$checkingpermission = "Checking for elevated permissions..."
$scriptout += $checkingpermission
Write-Host $checkingpermission -ForegroundColor Gray
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
[Security.Principal.WindowsBuiltInRole] "Administrator"))
{
	$nopermission = "Insufficient permissions to run this script. Open the PowerShell console as an administrator and run this script again."
	$scriptout += $nopermission
	Write-Warning $nopermission
	sleep 5
	Break
}
else
{
	$permissiongranted = " Currently running as administrator - proceeding with script execution..."
	$out += $permissiongranted
	Write-Host $permissiongranted -ForegroundColor Green
}


function Start-ScomDataCollector
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $false,
				   Position = 1)]
		[switch]$CheckTLSRegKeys,
		[Parameter(Mandatory = $false,
				   Position = 2)]
		[switch]$CheckCertificates,
		[Parameter(Mandatory = $false,
				   Position = 3)]
		[switch]$GetEventLogs,
		[Parameter(Mandatory = $false,
				   Position = 4)]
		[switch]$MSInfo32,
		[Parameter(Mandatory = $false,
				   Position = 5)]
		[switch]$AssumeYes,
		[Parameter(Mandatory = $false,
				   Position = 6)]
		[switch]$ExportMPs,
		[Parameter(Mandatory = $false,
				   Position = 7)]
		[string]$CaseNumber
		
	)
	
	#=================================================================================
	#  SCOM Health SQL Query Collection Script
	#
	#  Author: Kevin Holman
	#  v1.5
	#  Heavily modified, with permission, by Michael Kallhoff (mikallho) & Blake Drumm (v-bdrumm)
	#  v3.1.1 - 9/8/2020
	#=================================================================================
	# Constants section - modify stuff here:
	#=================================================================================
	#$OpsDB_SQLServer = "SQL2A.opsmgr.net"
	#$OpsDB_SQLDBName =  "OperationsManager"
	#$DW_SQLServer = "SQL2A.opsmgr.net"
	#$DW_SQLDBName =  "OperationsManagerDW"
	#=================================================================================
	# Begin MAIN script section
	#=================================================================================
	#Clear-Host
	# Check if this is running on a SCOM Management Server
	# Get SQLServer info from Registry if so
	Import-Module OperationsManager -ErrorAction SilentlyContinue
	$MSKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups"
	IF (Test-Path $MSKey)
	{
		# This is a management server.  Try to get the database values.
		$SCOMKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup"
		$SCOMData = Get-ItemProperty $SCOMKey
		$OpsDB_SQLServer = ($SCOMData).DatabaseServerName
		$OpsDB_SQLDBName = ($SCOMData).DatabaseName
		$DW_SQLServer = ($SCOMData).DataWarehouseDBServerName
		$DW_SQLDBName = ($SCOMData).DataWarehouseDBName
		$mgmtserver = 1
	}
	ELSE
	{
		if ($RemoteMGMTserver)
		{
			$ComputerName = $RemoteMGMTserver
		}
		else
		{
			$ComputerName = read-host "Please enter the name of a SCOM management server $env:userdomain\$env:USERNAME has permissions on"
		}
		$Hive = [Microsoft.Win32.RegistryHive]::LocalMachine
		$KeyPath = 'SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup'
		$OpsDBServer = 'DatabaseServerName'
		$OpsDBName = 'DatabaseName'
		$DWServer = 'DataWarehouseDBServerName'
		$DWDB = 'DataWarehouseDBName'
		$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($Hive, $ComputerName)
		$key = $reg.OpenSubKey($KeyPath)
		$OpsDB_SQLServer = $key.GetValue($OpsDBServer)
		$OpsDB_SQLDBName = $key.GetValue($OpsDBName)
		$DW_SQLServer = $key.GetValue($DWServer)
		$DW_SQLDBName = $key.GetValue($DWDB)
	}
	
	## strip fqdn etc...
	If ($OpsDB_SQLServer -like "*.*")
	{
		$OpsDB_SQLServer = $OpsDB_SQLServer.split('.')[0]
	}
	If ($DW_SQLServer -like "*.*")
	{
		$DW_SQLServer = $DW_SQLServer.split('.')[0]
	}
	
	## strip fqdn etc...
	If ($OpsDB_SQLServer -like "*,*")
	{
		$OpsDB_SQLServer = $OpsDB_SQLServer.split(',')[0]
	}
	If ($DW_SQLServer -like "*,*")
	{
		$DW_SQLServer = $DW_SQLServer.split(',')[0]
	}
	
	$Populated = 1
	
	## Verify variables are populated
	If ($OpsDB_SQLServer -eq $null)
	{
		write-output "OpsDBServer not found"
		$populated = 0
	}
	If ($DW_SQLServer -eq $null)
	{
		write-output "DataWarehouse server not found"
		$populated = 0
	}
	If ($OpsDB_SQLDBName -eq $null)
	{
		write-output "OpsDBName Not found"
		$populated = 0
	}
	If ($DW_SQLDBName -eq $null)
	{
		write-output "DWDBName not found"
		$populated = 0
	}
	
	if ($Populated = 0)
	{
		"At least some SQL Information not found, exiting script..."
    <# 
        insert Holman's method from the original script here, then remove the break found below
    #>
		break
	}
	
	## Hate this output. Want to change it, will eventually, doesnt pose a problem functionally though 
	## so thats a task for a later date. Want a table, not a list like that. 
	## Combine the objects into a single object and display via table.
	$color = "Cyan"
	Write-Output " "
	Write-Host "OpsDB Server : $OpsDB_SQLServer" -ForegroundColor $color
	Write-Host "OpsDB Name   : $OpsDB_SQLDBName" -ForegroundColor $color
	Write-Output " "
	Write-Host "DWDB Server  : $DW_SQLServer" -ForegroundColor $color
	Write-Host "DWDB Name    : $DW_SQLDBName" -ForegroundColor $color
	Write-Output " "
	if (!$AssumeYes)
	{
		do
		{
			
			$answer = Read-Host -Prompt "Do you want to continue with these values? (Y/N)"
			
		}
		until ($answer -eq "y" -or $answer -eq "n")
	}
	else { $answer = "y" }
	IF ($answer -eq "y")
	{
		Write-Host "Connecting to SQL Server...." -ForegroundColor DarkGreen
	}
	ELSE
	{
		do
		{
			
			$answer = Read-Host -Prompt "Do you want to attempt to continue without Queries to your SQL Server? (Y/N)"
			
		}
		until ($answer -eq "y" -or $answer -eq "n")
		if ($answer -eq "n")
		{
			Write-Warning "Exiting script...."
			exit
		}
		Write-Warning "Be aware, this has not been implemented yet..."
	}
	# Query the OpsDB Database
	$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
	[string]$currentuser = ([Environment]::UserDomainName + "\" + [Environment]::UserName)
	if (!$AssumeYes)
	{
		Write-Host "Currently Detecting User as: $currentuser"
		do
		{
			$answer2 = Read-Host -Prompt " Does the above user have the correct permissions to perform SQL Queries against $OpsDB_SQLServer`? (Y/N)"
		}
		until ($answer2 -eq "y" -or $answer2 -eq "n")
	}
	else { $answer2 = "y" }
	if ($answer2 -eq "n")
	{
		do
		{
			$answer3 = Read-Host -Prompt "  Are you setup for `'SQL Credentials`' or `'Domain Credentials`' on $OpsDB_SQLServer`? (SQL/Domain)"
		}
		until ($answer3 -eq "SQL" -or $answer3 -eq "Domain")
		$SQLuser = Read-Host '   What is your username?'
		$SQLpass = Read-Host '   What is your password?' -AsSecureString
		do
		{
			$proceed = Read-Host "    Would you like to proceed with $SQLuser`? (Y/N)"
			if ($proceed -eq "n")
			{
				$SQLuser = $null
				$SQLuser = Read-Host '   What is your username?'
				$SQLpass = Read-Host '   What is your password?' -AsSecureString
			}
		}
		until ($proceed -eq "y")
	}
	if ($answer2 -eq "y")
	{
		$SqlConnection.ConnectionString = "Server=$OpsDB_SQLServer;Database=$OpsDB_SQLDBName;Integrated Security=True"
	}
	elseif ($answer3 -eq "Domain")
	{
		$SqlConnection.ConnectionString = "Server=$OpsDB_SQLServer;user id=$SQLuser;password=$SQLpass;Database=$OpsDB_SQLDBName;Integrated Security=True"
	}
	elseif ($answer3 -eq "SQL")
	{
		$SqlConnection.ConnectionString = "Server=$OpsDB_SQLServer;user id=$SQLuser;password=$SQLpass;Database=$OpsDB_SQLDBName"
	}
	$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
	$SqlCmd.Connection = $SqlConnection
	# Below is how long we will wait before terminating an indivdual query
	$SqlCmd.CommandTimeout = 30
	#Get the script path
	[string]$ScriptPath = $PSScriptRoot
	$OutputPath = "$ScriptPath\output"
	IF (!(Test-Path $OutputPath))
	{
		Write-Host "Output folder not found.  Creating folder...." -ForegroundColor Gray
		md $OutputPath | out-null
		md $OutputPath\CSV | out-null
	}
	$QueriesPath = "$ScriptPath\queries\OpsDB"
	IF (!(Test-Path $QueriesPath))
	{
		Write-Warning "Path to query files not found ($QueriesPath).  Terminating...."
		break
	}
	Write-Host "`n================================"
	Write-Host "Starting SQL Query Gathering"
	Write-Host "Running SQL Queries against Operations Database"
	Write-Host " Looking for query files in: $QueriesPath" -ForegroundColor DarkGray
	$QueryFiles = Get-ChildItem $QueriesPath | where { $_.Extension -eq ".sql" }
	$QueryFilesCount = $QueryFiles.Count
	Write-Host "  Found ($QueryFilesCount) queries" -ForegroundColor Green
	FOREACH ($QueryFile in $QueryFiles)
	{
		try
		{
			$Error.Clear()
			$QueryFileName = $QueryFile.Name
			Write-Host "    Running query: " -ForegroundColor Cyan -NoNewline
			Write-Host "$QueryFileName" -ForegroundColor Magenta
			$QueryFileName = $QueryFileName.split('.')[0]
			$OutputFileName = $OutputPath + "\" + $QueryFileName + ".csv"
			[string]$SqlQuery = Get-Content $QueriesPath\$QueryFile -Raw
			$SqlCmd.CommandText = $SqlQuery
			$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
			$SqlAdapter.SelectCommand = $SqlCmd
			$ds = New-Object System.Data.DataSet
			$SqlAdapter.Fill($ds) | Out-Null
			#write-output "Writing output file" $OutputFileName
			# Check for errors connecting to SQL
			IF ($Error)
			{
				Write-Host "      Error running SQL query: $QueryFileName
" -ForegroundColor Red
				$Error | Export-Csv $OutputFileName -NoTypeInformation
			}
			ELSE
			{
				$ds.Tables[0] | Export-Csv $OutputFileName -NoTypeInformation
			}
		}
		catch
		{
			Write-Host "      Error running SQL query: $QueryFileName
" -ForegroundColor Red
			$_ | Export-Csv $OutputFileName -NoTypeInformation
		}
		
	}
	$SqlConnection.Close()
	# Query the DW database
	$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
	if (!$AssumeYes)
	{
		Write-Host "Currently Detecting User as: $currentuser"
		do
		{
			$answer4 = Read-Host -Prompt " Does the above user have the correct permissions to perform SQL Queries against $DW_SQLServer`? (Y/N)"
		}
		until ($answer4 -eq "y" -or $answer4 -eq "n")
	}
	else { $answer4 = "y" }
	if ($answer4 -eq "n")
	{
		do
		{
			$answer5 = Read-Host -Prompt "  Are you setup for `'SQL Credentials`' or `'Domain Credentials`' on $DW_SQLServer`? (SQL/Domain)"
		}
		until ($answer5 -eq "SQL" -or $answer5 -eq "Domain")
		$SQLuser2 = Read-Host '    What is your username?'
		$SQLpass2 = Read-Host '    What is your password?' -AsSecureString
		do
		{
			$proceed2 = Read-Host "   Would you like to proceed with $SQLuser2`? (Y/N)"
			if ($proceed2 -eq "n")
			{
				$SQLuser2 = $null
				$SQLuser2 = Read-Host '    What is your username?'
				$SQLpass2 = Read-Host '    What is your password?' -AsSecureString
			}
		}
		until ($proceed2 -eq "y")
	}
	if ($answer4 -eq "y")
	{
		$SqlConnection.ConnectionString = "Server=$DW_SQLServer;Database=$DW_SQLDBName;Integrated Security=True"
	}
	elseif ($answer5 -eq "Domain")
	{
		$SqlConnection.ConnectionString = "Server=$DW_SQLServer;user id=$SQLuser2;password=$SQLpass2;Database=$DW_SQLDBName;Integrated Security=True"
	}
	elseif ($answer5 -eq "SQL")
	{
		$SqlConnection.ConnectionString = "Server=$DW_SQLServer;user id=$SQLuser2;password=$SQLpass2;Database=$DW_SQLDBName"
	}
	$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
	$SqlCmd.Connection = $SqlConnection
	# Below is how long we will wait before terminating an individual query
	$SqlCmd.CommandTimeout = 30
	$QueriesPath = "$ScriptPath\queries\DW"
	IF (!(Test-Path $QueriesPath))
	{
		Write-Error "Path to query files not found ($QueriesPath).  Terminating...."
		break
	}
	Write-Host "`n================================"
	Write-Host "Running SQL Queries against Data Warehouse"
	Write-Host " Gathering query files located here: $QueriesPath" -ForegroundColor DarkGray
	$QueryFiles = Get-ChildItem $QueriesPath | where { $_.Extension -eq ".sql" }
	$QueryFilesCount = $QueryFiles.Count
	Write-Host "  Found ($QueryFilesCount) queries" -ForegroundColor Green
	FOREACH ($QueryFile in $QueryFiles)
	{
		try
		{
			$Error.Clear()
			$QueryFileName = $QueryFile.Name
			Write-Host "    Running query: " -ForegroundColor Cyan -NoNewline
			Write-Host "$QueryFileName" -ForegroundColor Magenta
			$QueryFileName = $QueryFileName.split('.')[0]
			$OutputFileName = $OutputPath + "\csv\" + $QueryFileName + ".csv"
			[string]$SqlQuery = Get-Content $QueriesPath\$QueryFile
			$SqlCmd.CommandText = $SqlQuery
			$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
			$SqlAdapter.SelectCommand = $SqlCmd
			$ds = New-Object System.Data.DataSet
			$SqlAdapter.Fill($ds) | Out-Null
			#write-output "Writing output file" $OutputFileName
			# Check for errors connecting to SQL
			IF ($Error)
			{
				Write-Host "      Error running SQL query: $QueryFileName
" -ForegroundColor Red
				$Error | Export-Csv $OutputFileName -NoTypeInformation
			}
			ELSE
			{
				$ds.Tables[0] | Export-Csv $OutputFileName -NoTypeInformation
			}
		}
		catch
		{
			Write-Host "      Error running SQL query: $QueryFileName
" -ForegroundColor Red
			$_ | Export-Csv $OutputFileName -NoTypeInformation
		}
	}
	$SqlConnection.Close()
	
	
<#
	.SYNOPSIS
		OMCertCheck.ps1
	
	.DESCRIPTION
		The steps for configuring certificates in System Center Operations Manager are numerous and one can easily get them confused.
		I see posts to the newsgroups and discussion lists regularly trying to troubleshoot why certificate authentication is not working, perhaps for a workgroup machine or gateway.
		Sometimes it takes 3 or 4 messages back and forth before I or anyone else can diagnose what the problem actually is but once this is finally done we can suggest how to fix the problem.

		In an attempt to make this diagnosis stage easier I put together a PowerShell script that automatically checks installed certificates for the needed properties and configuration. 
		If you think everything is set up correctly but the machines just won't communicate, try running this script on each computer and it will hopefully point you to the issue.
		I have tried to provide useful knowledge for fixing the problems.

		This script is for stand-alone PowerShell 1.0 - it does not require the OpsMgr PowerShell snapins.
		Technet Article: https://gallery.technet.microsoft.com/scriptcenter/Troubleshooting-OpsMgr-27be19d3
	
	.EXAMPLE
				PS C:\> .\OMCertCheck.ps1
	
	.NOTES
	Original Publish Date 1/2009
	    (Lincoln Atkinson?, https://blogs.technet.microsoft.com/momteam/author/latkin/ )

	 Update 08/2020 (Blake Drumm, https://github.com/v-bldrum/ )
	    Fixed formatting in output.
	 Update 06/2020 (Blake Drumm, https://github.com/v-bldrum/ )
	    Added ability to output script to file.
	
	 Update 2017.11.17 (Tyson Paul, https://blogs.msdn.microsoft.com/tysonpaul/ )
	    Fixed certificate SerialNumber parsing error. 
	
	 Update 2/2009
	    Fixes for subjectname validation
	    Typos
	    Modification for CA chain validation
	    Adds needed check for MachineKeyStore property on the private key
	
	 Update 7/2009
	    Fix for workgroup machine subjectname validation
#>
	
	
<#
	.SYNOPSIS
		A brief description of the SCOM-CertCheck function.
	
	.DESCRIPTION
		A detailed description of the SCOM-CertCheck function.
	
	.PARAMETER Output
		Full Path to Location where you want to Output this script.
	
	.EXAMPLE
		PS C:\> SCOM-CertCheck
	
	.NOTES
		Additional information about the function.
#>
	
	function SCOM-CertCheck
	{
		[CmdletBinding()]
		[OutputType([string])]
		param
		(
			[Parameter(Mandatory = $false,
					   Position = 1)]
			[String]$Output = "C:\Windows\temp\SCOM-CertChecker-Output.txt",
			[Parameter(Position = 2)]
			[Array]$Servers
		)
		if ($null -eq $Servers) { $Servers = $env:COMPUTERNAME }
		$Servers = $Servers | select -Unique
		[string[]]$out = @()
		foreach ($server in $Servers)
		{
			Write-Output " "
			Write-Output "Certificate Checker"
			Invoke-Command -ComputerName $server {
				Function Time-Stamp
				{
					
					$TimeStamp = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
					return $TimeStamp
				}
				# Consider all certificates in the Local Machine "Personal" store
				$certs = [Array] (dir cert:\LocalMachine\my\)
				$out = [Array] @()
				$text1 += "Checking that there are certificates in the Local Machine Personal store for $env:COMPUTERNAME......"
				$time = Time-Stamp
				$out += @"
$time : Starting Script
 
"@
				$out += $text1
				Write-Host $text1
				if ($certs -eq $null)
				{
					$text2 = @"
    There are no certificates in the Local Machine `"Personal`" store.
    This is where the client authentication certificate should be imported.
    Check if certificates were mistakenly imported to the Current User
    `"Personal`" store or the `"Operations Manager`" store.
"@
					Write-Host $text2 -ForegroundColor Red
					$out += $text2
					exit
				}
				
				$text3 = "Verifying each cert..."
				$out += $text3
				Write-Host $text3
				foreach ($cert in $certs)
				{
					$text4 = @"

Examining Certificate - Subject: $($cert.Issuer -replace "CN=", $null) - Serial Number $($cert.SerialNumber)
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
"@
					Write-Host $text4
					$out += $text4
					
					$pass = $true
					
					# Check subjectname
					
					$pass = &{
						$fqdn = $env:ComputerName
						$fqdn += "." + [DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain().Name
						trap [DirectoryServices.ActiveDirectory.ActiveDirectoryObjectNotFoundException]
						{
							# Not part of a domain
							continue;
						}
						
						$fqdnRegexPattern = "CN=" + $fqdn.Replace(".", "\.") + '(,.*)?$'
						
						if (!($cert.SubjectName.Name -match $fqdnRegexPattern))
						{
							$text5 = "Certificate Subjectname"
							$out += $text5
							Write-Host $text5 -BackgroundColor Red -ForegroundColor Black
							
							$text6 = @"
    The Subjectname of this certificate does not match the FQDN of this machine.
    Actual: $($cert.SubjectName.Name)
    Expected (case insensitive): CN=$fqdn
"@
							$out += $text6
							Write-Host $text6
							$false
						}
						else { $true; $text7 = "Certificate Subjectname"; $out += $text7; Write-Host $text7 -BackgroundColor Green -ForegroundColor Black }
					}
					
					# Verify private key
					
					if (!($cert.HasPrivateKey))
					{
						$text8 = "Private Key"
						$out += $text8
						Write-Host $text8 -BackgroundColor Red -ForegroundColor Black
						$text9 = @"
    This certificate does not have a private key.
    Verify that proper steps were taken when installing this cert.
"@
						$out += $text9
						Write-Host $text9
						$pass = $false
					}
					elseif (!($cert.PrivateKey.CspKeyContainerInfo.MachineKeyStore))
					{
						$text10 = "Private Key"
						$out += $text10
						Write-Host $text10 -BackgroundColor Red -ForegroundColor Black
						$text11 = @"
	This certificate's private key is not issued to a machine account.
	One possible cause of this is that the certificate
	was issued to a user account rather than the machine,
	then copy/pasted from the Current User store to the Local
	Machine store.  A full export/import is required to switch
	between these stores.
"@
						$out += $text11
						Write-Host $text11
						$pass = $false
					}
					else { $text12 = "Private Key"; $out += $text12; Write-Host $text12 -BackgroundColor Green -ForegroundColor Black }
					
					# Check expiration dates
					
					if (($cert.NotBefore -gt [DateTime]::Now) -or ($cert.NotAfter -lt [DateTime]::Now))
					{
						$text13 = "Expiration"
						$out += $text13
						Write-Host $text13 -BackgroundColor Red -ForegroundColor Black
						$text14 = @"
    This certificate is not currently valid.
    It will be valid between $($cert.NotBefore) and $($cert.NotAfter)
"@
						$out += $text14
						Write-Host $text14
						$pass = $false
					}
					else
					{
						$text15 = @"
Expiration
    Not Expired :: (valid from $($cert.NotBefore) thru $($cert.NotAfter))
"@
						$out += $text15
						Write-Host $text15 -BackgroundColor Green -ForegroundColor Black
					}
					
					
					# Enhanced key usage extension
					
					$enhancedKeyUsageExtension = $cert.Extensions | ? { $_.ToString() -match "X509EnhancedKeyUsageExtension" }
					if ($enhancedKeyUsageExtension -eq $null)
					{
						$text16 = "Enhanced Key Usage Extension"
						$out += $text16
						Write-Host $text16 -BackgroundColor Red -ForegroundColor Black
						$text17 = "No enhanced key usage extension found."
						$out += $text17
						Write-Host $text17
						$pass = $false
					}
					else
					{
						$usages = $enhancedKeyUsageExtension.EnhancedKeyUsages
						if ($usages -eq $null)
						{
							$text18 = "Enhanced Key Usage Extension"
							$out += $text18
							Write-Host $text18 -BackgroundColor Red -ForegroundColor Black
							$text19 = "    No enhanced key usages found."
							$out += $text19
							Write-Host $text19
							$pass = $false
						}
						else
						{
							$srvAuth = $cliAuth = $false
							foreach ($usage in $usages)
							{
								if ($usage.Value -eq "1.3.6.1.5.5.7.3.1") { $srvAuth = $true }
								if ($usage.Value -eq "1.3.6.1.5.5.7.3.2") { $cliAuth = $true }
							}
							if ((!$srvAuth) -or (!$cliAuth))
							{
								$text20 = "Enhanced Key Usage Extension"
								$out += $text20
								Write-Host $text20 -BackgroundColor Red -ForegroundColor Black
								$text21 = @"
    Enhanced key usage extension does not meet requirements.
    Required EKUs are 1.3.6.1.5.5.7.3.1 and 1.3.6.1.5.5.7.3.2
    EKUs found on this cert are:
"@
								
								$usages | %{ $text22 = "$($_.Value)"; $out += $text22; Write-Host $text22 }
								$pass = $false
							}
							else
							{
								$text23 = @"
Enhanced Key Usage Extension
    Meets Requirements
"@;
								$out += $text23; Write-Host $text23 -BackgroundColor Green -ForegroundColor Black
							}
						}
					}
					
					# KeyUsage extension
					
					$keyUsageExtension = $cert.Extensions | ? { $_.ToString() -match "X509KeyUsageExtension" }
					if ($keyUsageExtension -eq $null)
					{
						$text24 = "Key Usage Extensions"
						$out += $text24
						Write-Host $text24 -BackgroundColor Red -ForegroundColor Black
						$text25 = @"
    No key usage extension found.
    A KeyUsage extension matching 0xA0 (Digital Signature, Key Encipherment)
    or better is required.
"@
						$out += $text25
						Write-Host $text25
						$pass = $false
					}
					else
					{
						$usages = $keyUsageExtension.KeyUsages
						if ($usages -eq $null)
						{
							$text26 = "Key Usage Extensions"
							$out += $text26
							Write-Host $text26 -BackgroundColor Red -ForegroundColor Black
							$text27 = @"
    No key usages found.
    A KeyUsage extension matching 0xA0 (DigitalSignature, KeyEncipherment)
    or better is required.
"@
							$out += $text27
							Write-Host $text27
							$pass = $false
						}
						else
						{
							if (($usages.value__ -band 0xA0) -ne 0xA0)
							{
								$text28 = "Key Usage Extensions"
								$out += $text28
								Write-Host $text28 -BackgroundColor Red -ForegroundColor Black
								$text29 = @"
    Key usage extension exists but does not meet requirements.
    A KeyUsage extension matching 0xA0 (Digital Signature, Key Encipherment)
    or better is required.
    KeyUsage found on this cert matches:
    $usages"
"@
								$out += $text29
								Write-Host $text29
								$pass = $false
							}
							else { $text30 = "Key Usage Extensions"; $out += $text30; Write-Host $text30 -BackgroundColor Green -ForegroundColor Black }
						}
					}
					
					# KeySpec
					
					$keySpec = $cert.PrivateKey.CspKeyContainerInfo.KeyNumber
					if ($keySpec -eq $null)
					{
						$text31 = "KeySpec"
						$out += $text31
						Write-Host $text31 -BackgroundColor Red -ForegroundColor Black
						$text32 = "    Keyspec not found.  A KeySpec of 1 is required"
						$out += $text32
						Write-Host $text32
						$pass = $false
					}
					elseif ($keySpec.value__ -ne 1)
					{
						$text33 = "KeySpec"
						$out += $text33
						Write-Host $text33 -BackgroundColor Red -ForegroundColor Black
						$text34 = @"
    Keyspec exists but does not meet requirements.
    A KeySpec of 1 is required.
    KeySpec for this cert: $($keySpec.value__)
"@
						$out += $text34
						Write-Host $text34
						$pass = $false
					}
					else { $text35 = "KeySpec"; $out += $text35; Write-Host $text35 -BackgroundColor Green -ForegroundColor Black }
					
					
					# Check that serial is written to proper reg
					
					$certSerial = $cert.SerialNumber
					$certSerialReversed = [System.String]("")
					-1 .. -19 | % { $certSerialReversed += $certSerial[2 * $_] + $certSerial[2 * $_ + 1] }
					
					if (! (Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"))
					{
						$text36 = "Serial Number written to registry"
						$out += $text36
						Write-Host $text36 -BackgroundColor Red -ForegroundColor Black
						$text37 = @"
    The certificate serial number is not written to registry.
    Need to run MomCertImport.exe
"@
						$out += $text37
						Write-Host $text37
						$pass = $false
					}
					else
					{
						$regKeys = get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Machine Settings"
						if ($regKeys.ChannelCertificateSerialNumber -eq $null)
						{
							$text38 = "Serial Number written to registry"
							$out += $text38
							Write-Host $text38 -BackgroundColor Red -ForegroundColor Black
							$text39 = @"
    The certificate serial number is not written to registry.
    Need to run MomCertImport.exe
"@
							$out += $text39
							Write-Host $text39
							$pass = $false
						}
						else
						{
							$regSerial = ""
							$regKeys.ChannelCertificateSerialNumber | % { $regSerial += $_.ToString("X2") }
							if ($regSerial -eq "" -or $null) { $regSerial = "`{Empty`}" }
							if ($regSerial -ne $certSerialReversed)
							{
								$text40 = "Serial Number written to registry"
								$out += $text40
								Write-Host $text40 -BackgroundColor Red -ForegroundColor Black
								$text41 = @"
    The serial number written to the registry does not match this certificate
    Expected registry entry: $certSerialReversed
    Actual registry entry:   $regSerial
"@
								$out += $text41
								Write-Host $text41
								$pass = $false
							}
							else { $text42 = "Serial Number written to registry"; $out += $text42; Write-Host $text42 -BackgroundColor Green -ForegroundColor Black }
						}
					}
					
<#
	Check that the cert's issuing CA is trusted (This is not technically required
	as it is the remote machine cert's CA that must be trusted.  Most users leverage
	the same CA for all machines, though, so it's worth checking
#>
					$chain = new-object Security.Cryptography.X509Certificates.X509Chain
					$chain.ChainPolicy.RevocationMode = 0
					if ($chain.Build($cert) -eq $false)
					{
						$text43 = "Certification Chain"
						$out += $text43
						Write-Host $text43 -BackgroundColor Yellow -ForegroundColor Black
						$text44 = @"
    The following error occurred building a certification chain with this certificate:
    $($chain.ChainStatus[0].StatusInformation)
    This is an error if the certificates on the remote machines are issued
    from this same CA - $($cert.Issuer)
    Please ensure the certificates for the CAs which issued the certificates configured
    on the remote machines is installed to the Local Machine Trusted Root Authorities
    store on this machine.
"@
						$out += $text44
						Write-Host $text44
					}
					else
					{
						$rootCaCert = $chain.ChainElements | select -property Certificate -last 1
						$localMachineRootCert = dir cert:\LocalMachine\Root | ? { $_ -eq $rootCaCert.Certificate }
						if ($localMachineRootCert -eq $null)
						{
							$text45 = "Certification Chain"
							$out += $text45
							Write-Host $text45 -BackgroundColor Yellow -ForegroundColor Black
							$text46 = @"
    This certificate has a valid certification chain installed, but
    a root CA certificate verifying the issuer $($cert.Issuer)
    was not found in the Local Machine Trusted Root Authorities store.
    Make sure the proper root CA certificate is installed there, and not in
    the Current User Trusted Root Authorities store.
"@
							$out += $text46
							Write-Host $text46
						}
						else
						{
							$text47 = "Certification Chain"
							$out += $text47
							Write-Host $text47 -BackgroundColor Green -ForegroundColor Black
							$text48 = @"
    There is a valid certification chain installed for this cert,
    but the remote machines' certificates could potentially be issued from
    different CAs.  Make sure the proper CA certificates are installed
    for these CAs.
"@
							$out += $text48
							Write-Host $text48
						}
						
					}
					
					
					if ($pass) { $text49 = "***This certificate is properly configured and imported for System Center Operations Manager.***"; $out += $text49; Write-Host $text49 -ForegroundColor Green }
				}
				if ($Output)
				{
					$time = Time-Stamp
					$out += @"

$time : Script Completed
"@
					$out | Out-File $Output
				}
				#& C:\Windows\explorer.exe "/select,$Output"
				return $out
			}
		}
	}
	
	
	Function Get-SCOMEventLogs
	{
		[cmdletbinding()]
		param (
			[String[]]$Servers
		)
		
		[String[]]$Logs = "Application", "System", "Operations Manager"
		$servers = $servers | select -Unique
		
		foreach ($server in $servers)
		{
			Write-Output " "
			foreach ($log in $logs)
			{
				If ($Comp -match $server)
				{
					# If running locally do the below
					Write-Host "    Locally " -NoNewline -ForegroundColor DarkCyan
					Write-Host "Exporting Event Log " -NoNewline -ForegroundColor Cyan
					Write-Host "on " -NoNewline -ForegroundColor DarkCyan
					Write-Host "$server " -NoNewline -ForegroundColor Cyan
					Write-Host ": " -NoNewline -ForegroundColor DarkCyan
					Write-Host "$log" -NoNewline -ForegroundColor Cyan
					$fileCheck = test-path "c:\windows\Temp\$server.$log.evtx"
					if ($fileCheck -eq $true)
					{
						Remove-Item "c:\windows\Temp\$server.$log.evtx" -Force
					}
					Write-Host "-" -NoNewline -ForegroundColor Green;
					$eventcollect = wevtutil epl $log "c:\windows\Temp\$server.$log.evtx"; wevtutil al "c:\windows\Temp\$server.$log.evtx"
					do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
					while ($eventcollect)
					Write-Host "> Collected Events`n" -NoNewline -ForegroundColor Green
					try
					{
						Write-Host "     Locally moving files using Move-Item" -NoNewline -ForegroundColor DarkCyan
						$movelocalevtx = Move-Item "C:\Windows\temp\$server.$log.evtx" $ScriptPath\output -force -ErrorAction Stop; Move-Item "C:\Windows\temp\localemetadata\*.mta" $ScriptPath\output -force -ErrorAction Stop
						Write-Host "-" -NoNewline -ForegroundColor Green
						do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
						while ($movelocalevtx | Out-Null)
						Write-Host "> Transfer Completed!" -NoNewline -ForegroundColor Green
						Write-Output " "
						continue
					}
					catch
					{
						Write-Warning $_
					}
					try
					{
						Write-Host "     Locally moving files using Robocopy" -NoNewline -ForegroundColor DarkCyan
						Robocopy "C:\Windows\temp" "$ScriptPath\output" "$server.$log.evtx" /MOVE /R:2 /W:10 | Out-Null
						Robocopy "C:\Windows\temp\localemetadata" "$ScriptPath\output" "*.MTA" /MOVE /R:2 /W:10 | Out-Null
						Write-Host "      Transfer Completed!" -NoNewline -ForegroundColor Green
						Write-Output " "
						continue
					}
					catch
					{
						Write-Warning $_
					}
				}
				else
				{
					# If not the Computer Running this Script, do the below.
					Write-Host "    Remotely " -NoNewline -ForegroundColor DarkCyan
					Write-Host "Exporting Event Log " -NoNewline -ForegroundColor Cyan
					Write-Host "on " -NoNewline -ForegroundColor DarkCyan
					Write-Host "$server " -NoNewline -ForegroundColor Cyan
					Write-Host ": " -NoNewline -ForegroundColor DarkCyan
					Write-Host "$log" -NoNewline -ForegroundColor Cyan
					Write-Host "-" -NoNewline -ForegroundColor Green
					Invoke-Command -ComputerName $server {
						
						
						$localAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
						if ($localadmin) { $LA = "$true" }
						else { $LA = "$false" }
						
						
						$fileCheck = test-path "c:\windows\Temp\$using:server.$using:log.evtx"
						if ($fileCheck -eq $true)
						{
							Remove-Item "c:\windows\Temp\$using:server.$using:log.evtx" -Force
						}
						Write-Host "-" -NoNewline -ForegroundColor Green
						if ($la -eq $true)
						{
							try
							{
								$eventcollect = wevtutil epl $using:log "c:\windows\Temp\$using:server.$using:log.evtx"; wevtutil al "c:\windows\Temp\$using:server.$using:log.evtx"
								do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
								while ($eventcollect)
								Write-Host "> Collected Events" -NoNewline -ForegroundColor Green
							}
							catch
							{
								Write-Warning $_
							}
						}
						Write-Output " "
						continue
					}
					try
					{
						Write-Host "     Transferring using Move-Item" -NoNewLine -ForegroundColor DarkCyan
						$moveevents = Move-Item "\\$server\c$\windows\temp\$server.$log.evtx" $ScriptPath\output -force -ErrorAction Stop; Move-Item "\\$server\c$\windows\temp\localemetadata\*.mta" $ScriptPath\output -force -ErrorAction Stop
						Write-Host "-" -NoNewline -ForegroundColor Green
						do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
						while ($moveevents)
						Write-Host "> Transfer Completed!" -NoNewline -ForegroundColor Green
						Write-Output " "
						continue
					}
					catch
					{
						Write-Warning $_
					}
					try
					{
						Write-Host "     Transferring using Robocopy" -NoNewline -ForegroundColor DarkCyan
						Robocopy "\\$server\c$\windows\temp" "$ScriptPath\output" "$server.$log.evtx" /MOVE /R:2 /W:10 | Out-Null
						Robocopy "\\$server\c$\windows\temp\localemetadata" "$ScriptPath\output" "*.MTA" /MOVE /R:2 /W:10 | Out-Null
						Write-Host "      Transfer Completed!" -NoNewline -ForegroundColor Green
						continue
					}
					catch
					{
						Write-Warning $_
					}
				}
			}
		}
		
	}
	Function Compare-TLSRegKeys
	{
		[CmdletBinding()]
		Param
		(
			[string[]]$Servers
		)
		[string[]]$ResultsData = @()
		foreach ($server in $servers)
		{
			$localresults = @()
			Invoke-Command -ComputerName $server {
				$LHost = $env:computername
				$ProtocolList = "TLS 1.0", "TLS 1.1", "TLS 1.2"
				$ProtocolSubKeyList = "Client", "Server"
				$DisabledByDefault = "DisabledByDefault"
				$Enabled = "Enabled"
				$registryPath = "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\"
				#write-output "Working on $LHost"
				foreach ($Protocol in $ProtocolList)
				{
					foreach ($key in $ProtocolSubKeyList)
					{
						#write-output "Checking for $protocol\$key"
						$currentRegPath = $registryPath + $Protocol + "\" + $key
						
						$IsDisabledByDefault = @()
						$IsEnabled = @()
						$localresults = @()
						if (!(Test-Path $currentRegPath))
						{
							#write-output "$currentRegPath Does not exist on $lhost"
							$IsDisabledByDefault = "Null"
							$IsEnabled = "Null"
						}
						else
						{
							$IsDisabledByDefault = (Get-ItemProperty -Path $currentRegPath -Name $DisabledByDefault -ea 0).DisabledByDefault
							if ($IsDisabledByDefault -eq 4294967295)
							{
								$IsDisabledByDefault = "0xffffffff"
							}
							if ($IsDisabledByDefault -eq $null)
							{
								$IsDisabledByDefault = "DoesntExist"
							}
							
							$IsEnabled = (Get-ItemProperty -Path $currentRegPath -Name $Enabled -ea 0).Enabled
							if ($IsEnabled -eq 4294967295)
							{
								$isEnabled = "0xffffffff"
							}
							if ($IsEnabled -eq $null)
							{
								$IsEnabled = "DoesntExist"
							}
							
						}
						$localresults = "PipeLineKickStart" | select @{ n = 'Server'; e = { $LHost } },
																	 @{ n = 'Protocol'; e = { $Protocol } },
																	 @{ n = 'Type'; e = { $key } },
																	 @{ n = 'DisabledByDefault'; e = { $IsDisabledByDefault } },
																	 @{ n = 'IsEnabled'; e = { $IsEnabled } }
						$localresults
					}
				}
			}
		}
	}
	
	#$TLSservers = import-csv $OutputPath\ManagementServers.csv
	$ManagementServers = (Get-SCOMManagementServer).DisplayName
	[string[]]$TLSservers = $ManagementServers
	[string[]]$TLSservers += $DW_SQLServer
	[string[]]$TLSservers += $OpsDB_SQLServer
	[string[]]$TLSservers = $TLSservers | select -Unique
	#$TLSservers += "DC22"   # fictitious server added to simulate a no access/server down situation
	
	[string[]]$TestedTLSservers = @()
	foreach ($Rsrv in $TLSservers)
	{
		$test = $null
		$test = test-path "\\$rsrv\c$"
		if ($test)
		{
			$TestedTLSservers += $rsrv
		}
		else
		{
			Write-Output " 
         Access to $rsrv Failed! Removing from Server Array! 
         Please verify that the server is online, and that your account has remote access to it."
		}
	}
	
	if ($CheckCertificates)
	{
		Write-Output " "
		Write-Output "================================`nStarting Certificate Checker"
		
		foreach ($CertChkSvr in $TestedTLSservers)
		{
			SCOM-CertCheck -Servers $CertChkSvr | Out-String | Add-Content $OutputPath\$CertChkSvr.CertificateInfo.txt
		}
	}
	
	if ($CheckTLSRegKeys)
	{
		# This will be updated with CipherSuite checks at some point
		Compare-TLSRegKeys -Servers $TestedTLSservers |
		sort server, protocol, type -Descending |
		ft Server, Protocol, Type, Disabledbydefault, IsEnabled -autosize |
		out-string |
		Add-Content $OutputPath\TLSRegKeys.txt
	}
	
	if ($GetEventLogs)
	{
		Write-Output " "
		Write-Output "================================`nStarting Event Log Gathering"
		if ((Test-Path -Path "$OutputPath\EventLogs") -eq $false)
		{
			Write-Host "  Creating Folder: $OutputPath\EventLogs" -ForegroundColor Gray
			md $OutputPath\EventLogs | out-null
			md $OutputPath\EventLogs\localemetadata | out-null
		}
		else
		{
			Write-Host "  Existing Folder Found: $OutputPath\EventLogs" -ForegroundColor Gray
			Remove-Item $OutputPath\EventLogs -Recurse | Out-Null
			Write-Host "   Deleting folder contents" -ForegroundColor Gray
			md $OutputPath\EventLogs | out-null
			md $OutputPath\EventLogs\localemetadata | out-null
			Write-Host "    Folder Created: $OutputPath\EventLogs" -ForegroundColor Gray
		}
		foreach ($ElogServer in $TestedTLSservers)
		{
			Get-SCOMEventLogs -Servers $ELogServer
		}
		Write-Output " "
	}
	
	if ($ExportMPs)
	{
		try
		{
			if ($mgmtserver = 1)
			{
				Write-Output "================================`nStarting Unsealed MP Export"
				if ((Test-Path -Path "$OutputPath\MPUnsealed") -eq $false)
				{
					Write-Host "  Creating Folder: $OutputPath\MPUnsealed" -ForegroundColor Gray
					md $OutputPath\MPUnsealed | Out-Null
				}
				else
				{
					Write-Host "  Existing Folder Found: $OutputPath\MPUnsealed" -ForegroundColor Gray
					Remove-Item $OutputPath\MPUnsealed -Recurse | Out-Null
					Write-Host "   Deleting folder contents" -ForegroundColor Gray
					md $OutputPath\MPUnsealed | out-null
					Write-Host "    Folder Created: $OutputPath\MPUnsealed" -ForegroundColor Gray
				}
				
				try
				{
					(Get-SCOMManagementPack).where{ $_.Sealed -eq $false } | Export-SCOMManagementPack -path $OutputPath\MPUnsealed | out-null
					Write-Host "    Completed Exporting Management Packs" -ForegroundColor Green
				}
				catch
				{
					Write-Warning $_
				}
				
    <#
        md $OutputPath\MPSealed | out-null
        try{
           (Get-SCOMManagementPack).where{$_.Sealed -eq $true} | Export-SCOMManagementPack -path $OutputPath\MPSealed
        }catch{
           
        }
    #>
				
			}
			else
			{
				Write-Warning "  Exporting Management Packs is only possible from a management server"
			}
		}
		catch { Write-Warning $_ }
	}
	
	if ($msinfo32)
	{
		write-output " "
		Write-Host "================================`nStarting MSInfo32 reporting"
		
		if ((Test-Path -Path "$OutputPath\MSInfo32") -eq $false)
		{
			md $OutputPath\MSInfo32 | out-null
		}
		else
		{
			Remove-Item $OutputPath\MSInfo32 -Recurse
		}
		try
		{
			$TestedTLSservers | % { $serv = $_; Write-Host "    Gathering MSInfo32 from: " -NoNewline; Write-Host "$serv" -ForegroundColor Cyan; Start-Process "msinfo32.exe" -ArgumentList "/report `"C:\windows\Temp\$_.msinfo32.txt`" /computer $serv" -NoNewWindow -Wait; $serv = $null; }
		}
		catch
		{
			Write-Warning "     Issue gathering MSInfo32 with this command: msinfo32.exe /report `"C:\Windows\Temp\$serv.msinfo32.txt`" /computer $serv"
			$sessions = New-PSSession -ComputerName $TestedTLSservers
			Invoke-Command -Session $sessions {
				$Name = $env:COMPUTERNAME
				$FileName = "$name" + ".msinfo32.txt"
				#msinfo32 /report "c:\windows\Temp\$FileName"
				msinfo32 /report "c:\windows\Temp\$FileName"
				$runtime = 6
				$Run = 1
				while ($Run -eq 1)
				{
					$running = $null
					$running = get-process msinfo32 -ea SilentlyContinue
					if ($running)
					{
						Write-Host "    MSInfo32 is still running on $name. Pausing 1 minute, and rechecking..."
						start-sleep -Seconds 60
						$run = 1
						$runtime = $runtime - 1
						if ($runtime -lt 1)
						{
							Write-Warning "    MSInfo32 process on $name appears hung, killing process"
							get-process msinfo32 | kill
							$run = 0
						}
					}
					else
					{
						$run = 0
					}
				}
			}
			Write-Host "    Completed on $name" -ForegroundColor
			Get-PSSession | Remove-PSSession
			write-Output " "
			Write-output "Moving MSInfo32 Reports to $env:COMPUTERNAME"
			foreach ($rserv in $TestedTLSservers)
			{
				Write-output " Retrieving MSInfo32 Report from $rserv"
				Move-Item "\\$rserv\c$\windows\Temp\*.msinfo32.nfo" "$OutputPath\MSInfo32"
				Write-Host "    Completed Retrieving MSInfo32 Report from $rserv" -ForegroundColor Green
			}
		}
	}
	write-Output " "
	Write-Output "================================`nGathering Agent(s) Pending Management"
	$pendingMgmt = Get-SCOMPendingManagement | Out-File -FilePath "$OutputPath\Pending Management.txt"
	Write-Host "    Running Powershell Command: " -NoNewLine -ForegroundColor Cyan
	Write-Host "`n      Get-SCOMPendingManagement" -NoNewLine -ForegroundColor Magenta
	Write-Host " against" -NoNewLine -ForegroundColor Cyan
	Write-Host " $env:COMPUTERNAME" -NoNewLine -ForegroundColor Magenta
	Write-Host "-" -NoNewline -ForegroundColor Green
	do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
	while ($pendingMgmt)
	Write-Host "> Command Execution Completed!`n" -NoNewline -ForegroundColor Green
	
	write-Output " "
	Write-Output "================================`nGathering System Center Operations Manager General Information"
	$setuplocation = get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup" | Select-Object * -exclude PSPath, PSParentPath, PSChildName, PSProvider, PSDrive
	$ServerVersionSwitch = switch ($setuplocation.ServerVersion)
	{
    <# 
       System Center Operations Manager 2019 Versions
    #>
		'10.19.10407.0' { "Update Rollup 2 for SCOM 2019 / 2020 August 4" }
		'10.19.10349.0' { "SCOM 2019 Hotfix for Alert Management / 2020 April 1" }
		'10.19.10311.0' { "Update Rollup 1 for SCOM 2019 / 2020 February 4" }
		'10.19.10050.0' { "SCOM 2019 / 2019 March 14" }
    <# 
       System Center Operations Manager Semi-Annual Channel (SAC) Versions
    #>
		'7.3.13261.0' { "Version 1807 / 2018 July 24" }
		'7.3.13142.0' { "Version 1801 / 2018 February 8" }
		'7.3.13040.0' { "Version 1711 (preview) / 2017 November 9" }
    <# 
       System Center Operations Manager 2016 Versions
    #>
		'7.2.12265.0' { "SCOM 2016 Update Rollup 9 / 2020 March 24" }
		'7.2.12213.0' { "SCOM 2016 Update Rollup 8 / 2019 September 24" }
		'7.2.12150.0' { "SCOM 2016 Update Rollup 7 / 2019 April 23" }
		'7.2.12066.0' { "SCOM 2016 Update Rollup 6 / 2018 October 23" }
		'7.2.12016.0' { "SCOM 2016 Update Rollup 5 / 2018 April 25" }
		'7.2.11938.0' { "SCOM 2016 Update Rollup 4 / 2017 October 23" }
		'7.2.11878.0' { "SCOM 2016 Update Rollup 3 / 2017 May 23" }
		'7.2.11822.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
		'7.2.11759.0' { "SCOM 2016 Update Rollup 1 / 2016 October 13" }
		'7.2.11719.0' { "SCOM 2016 RTM / 2016 September 26" }
		'7.2.11469.0' { "SCOM 2016 Technical Preview 5 / 2016 April" }
		'7.2.11257.0' { "SCOM 2016 Technical Preview 4 / 2016 July" }
		'7.2.11125.0' { "SCOM 2016 Technical Preview 3 / 2016 July" }
		'7.2.11097.0' { "SCOM 2016 Technical Preview 2 / 2016 June" }
		'7.2.10015.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
   <# 
      System Center Operations Manager 2012 R2 Versions
   #>
		'7.1.10226.1387' { "SCOM 2012 R2 Update Rollup 14 / 2017 November 28" }
		'7.1.10226.1360' { "SCOM 2012 R2 Update Rollup 13 / 2017 May 23" }
		'7.1.10226.1304' { "SCOM 2012 R2 Update Rollup 12 / 2017 January 24" }
		'7.1.10226.1239' { "SCOM 2012 R2 Update Rollup 11 / 2016 August 30" }
		'7.1.10226.1177' { "SCOM 2012 R2 Update Rollup 9 / 2016 January 26" }
		'7.1.10226.1118' { "SCOM 2012 R2 Update Rollup 8 / 2015 October 27" }
		'7.1.10226.1090' { "SCOM 2012 R2 Update Rollup 7 / 2015 August 11" }
		'7.1.10226.1064' { "SCOM 2012 R2 Update Rollup 6 / 2015 April 28" }
		'7.1.10226.1052' { "SCOM 2012 R2 Update Rollup 5 / 2015 February 10" }
		'7.1.10226.1046' { "SCOM 2012 R2 Update Rollup 4 / 2014 October 28" }
		'7.1.10226.1037' { "SCOM 2012 R2 Update Rollup 3 / 2014 July 29" }
		'7.1.10226.1015' { "SCOM 2012 R2 Update Rollup 2 / 2014 April 23" }
		'7.1.10226.1011' { "SCOM 2012 R2 Update Rollup 1 / 2014 January 27" }
		'7.1.10226.0' { "SCOM 2012 R2 RTM / 2013 October 22" }
   <# 
      System Center Operations Manager 2012 SP1 Versions
   #>
		'7.0.9538.0' { "SCOM 2012 SP1" }
		'7.0.9538.1005' { "SCOM 2012 SP1 Update Rollup 1 / 2013 January 8" }
		'7.0.9538.1047' { "SCOM 2012 SP1 Update Rollup 2 / 2013 April 08" }
		'7.0.9538.1069' { "SCOM 2012 SP1 Update Rollup 3 / 2013 July 23" }
		'7.0.9538.1084' { "SCOM 2012 SP1 Update Rollup 4 / 2013 October 21" }
		'7.0.9538.1106' { "SCOM 2012 SP1 Update Rollup 5 / 2014 January 27" }
		'7.0.9538.1109' { "SCOM 2012 SP1 Update Rollup 6 / 2014 April 23" }
		'7.0.9538.1117' { "SCOM 2012 SP1 Update Rollup 7 / 2014 July 29" }
		'7.0.9538.1123' { "SCOM 2012 SP1 Update Rollup 8 / 2014 October 28" }
		'7.0.9538.1126' { "SCOM 2012 SP1 Update Rollup 9 / 2015 February 10" }
		'7.0.9538.1136' { "SCOM 2012 SP1 Update Rollup 10 / 2015 August 11" }
   <# 
      System Center Operations Manager 2012 Versions
   #>
		'7.0.8289.0' { "SCOM 2012 Beta / 2011 July" }
		'7.0.8560.0' { "SCOM 2012 RTM" }
		'7.0.8560.1021' { "SCOM 2012 Update Rollup 1 / 2012 May 07" }
		'7.0.8560.1027' { "SCOM 2012 Update Rollup 2 / 2012 July 24" }
		'7.0.8560.1036' { "SCOM 2012 Update Rollup 3 / 2012 October 08" }
		'7.0.8560.1048' { "SCOM 2012 Update Rollup 8 / 2015 August 11" }
	}
	$setuplocation.ServerVersion = $ServerVersionSwitch + " (" + $setuplocation.ServerVersion + ")"
	
	$UIVersionSwitch = switch ($setuplocation.UIVersion)
	{
    <# 
       System Center Operations Manager 2019 Versions
    #>
		'10.19.10407.0' { "Update Rollup 2 for SCOM 2019 / 2020 August 4" }
		'10.19.10349.0' { "SCOM 2019 Hotfix for Alert Management / 2020 April 1" }
		'10.19.10311.0' { "Update Rollup 1 for SCOM 2019 / 2020 February 4" }
		'10.19.10050.0' { "SCOM 2019 / 2019 March 14" }
    <# 
       System Center Operations Manager Semi-Annual Channel (SAC) Versions
    #>
		'7.3.13261.0' { "Version 1807 / 2018 July 24" }
		'7.3.13142.0' { "Version 1801 / 2018 February 8" }
		'7.3.13040.0' { "Version 1711 (preview) / 2017 November 9" }
    <# 
       System Center Operations Manager 2016 Versions
    #>
		'7.2.12265.0' { "SCOM 2016 Update Rollup 9 / 2020 March 24" }
		'7.2.12213.0' { "SCOM 2016 Update Rollup 8 / 2019 September 24" }
		'7.2.12150.0' { "SCOM 2016 Update Rollup 7 / 2019 April 23" }
		'7.2.12066.0' { "SCOM 2016 Update Rollup 6 / 2018 October 23" }
		'7.2.12016.0' { "SCOM 2016 Update Rollup 5 / 2018 April 25" }
		'7.2.11938.0' { "SCOM 2016 Update Rollup 4 / 2017 October 23" }
		'7.2.11878.0' { "SCOM 2016 Update Rollup 3 / 2017 May 23" }
		'7.2.11822.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
		'7.2.11759.0' { "SCOM 2016 Update Rollup 1 / 2016 October 13" }
		'7.2.11719.0' { "SCOM 2016 RTM / 2016 September 26" }
		'7.2.11469.0' { "SCOM 2016 Technical Preview 5 / 2016 April" }
		'7.2.11257.0' { "SCOM 2016 Technical Preview 4 / 2016 July" }
		'7.2.11125.0' { "SCOM 2016 Technical Preview 3 / 2016 July" }
		'7.2.11097.0' { "SCOM 2016 Technical Preview 2 / 2016 June" }
		'7.2.10015.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
   <# 
      System Center Operations Manager 2012 R2 Versions
   #>
		'7.1.10226.1387' { "SCOM 2012 R2 Update Rollup 14 / 2017 November 28" }
		'7.1.10226.1360' { "SCOM 2012 R2 Update Rollup 13 / 2017 May 23" }
		'7.1.10226.1304' { "SCOM 2012 R2 Update Rollup 12 / 2017 January 24" }
		'7.1.10226.1239' { "SCOM 2012 R2 Update Rollup 11 / 2016 August 30" }
		'7.1.10226.1177' { "SCOM 2012 R2 Update Rollup 9 / 2016 January 26" }
		'7.1.10226.1118' { "SCOM 2012 R2 Update Rollup 8 / 2015 October 27" }
		'7.1.10226.1090' { "SCOM 2012 R2 Update Rollup 7 / 2015 August 11" }
		'7.1.10226.1064' { "SCOM 2012 R2 Update Rollup 6 / 2015 April 28" }
		'7.1.10226.1052' { "SCOM 2012 R2 Update Rollup 5 / 2015 February 10" }
		'7.1.10226.1046' { "SCOM 2012 R2 Update Rollup 4 / 2014 October 28" }
		'7.1.10226.1037' { "SCOM 2012 R2 Update Rollup 3 / 2014 July 29" }
		'7.1.10226.1015' { "SCOM 2012 R2 Update Rollup 2 / 2014 April 23" }
		'7.1.10226.1011' { "SCOM 2012 R2 Update Rollup 1 / 2014 January 27" }
		'7.1.10226.0' { "SCOM 2012 R2 RTM / 2013 October 22" }
   <# 
      System Center Operations Manager 2012 SP1 Versions
   #>
		'7.0.9538.0' { "SCOM 2012 SP1" }
		'7.0.9538.1005' { "SCOM 2012 SP1 Update Rollup 1 / 2013 January 8" }
		'7.0.9538.1047' { "SCOM 2012 SP1 Update Rollup 2 / 2013 April 08" }
		'7.0.9538.1069' { "SCOM 2012 SP1 Update Rollup 3 / 2013 July 23" }
		'7.0.9538.1084' { "SCOM 2012 SP1 Update Rollup 4 / 2013 October 21" }
		'7.0.9538.1106' { "SCOM 2012 SP1 Update Rollup 5 / 2014 January 27" }
		'7.0.9538.1109' { "SCOM 2012 SP1 Update Rollup 6 / 2014 April 23" }
		'7.0.9538.1117' { "SCOM 2012 SP1 Update Rollup 7 / 2014 July 29" }
		'7.0.9538.1123' { "SCOM 2012 SP1 Update Rollup 8 / 2014 October 28" }
		'7.0.9538.1126' { "SCOM 2012 SP1 Update Rollup 9 / 2015 February 10" }
		'7.0.9538.1136' { "SCOM 2012 SP1 Update Rollup 10 / 2015 August 11" }
   <# 
      System Center Operations Manager 2012 Versions
   #>
		'7.0.8289.0' { "SCOM 2012 Beta / 2011 July" }
		'7.0.8560.0' { "SCOM 2012 RTM" }
		'7.0.8560.1021' { "SCOM 2012 Update Rollup 1 / 2012 May 07" }
		'7.0.8560.1027' { "SCOM 2012 Update Rollup 2 / 2012 July 24" }
		'7.0.8560.1036' { "SCOM 2012 Update Rollup 3 / 2012 October 08" }
		'7.0.8560.1048' { "SCOM 2012 Update Rollup 8 / 2015 August 11" }
	}
	$setuplocation.UIVersion = $UIVersionSwitch + " (" + $setuplocation.UIVersion + ")"
	
	$CurrentVersionSwitch = switch ($setuplocation.CurrentVersion)
	{
    <# 
       System Center Operations Manager 2019 Versions
    #>
		'10.19.10407.0' { "Update Rollup 2 for SCOM 2019 / 2020 August 4" }
		'10.19.10349.0' { "SCOM 2019 Hotfix for Alert Management / 2020 April 1" }
		'10.19.10311.0' { "Update Rollup 1 for SCOM 2019 / 2020 February 4" }
		'10.19.10050.0' { "SCOM 2019 / 2019 March 14" }
    <# 
       System Center Operations Manager Semi-Annual Channel (SAC) Versions
    #>
		'7.3.13261.0' { "Version 1807 / 2018 July 24" }
		'7.3.13142.0' { "Version 1801 / 2018 February 8" }
		'7.3.13040.0' { "Version 1711 (preview) / 2017 November 9" }
    <# 
       System Center Operations Manager 2016 Versions
    #>
		'7.2.12265.0' { "SCOM 2016 Update Rollup 9 / 2020 March 24" }
		'7.2.12213.0' { "SCOM 2016 Update Rollup 8 / 2019 September 24" }
		'7.2.12150.0' { "SCOM 2016 Update Rollup 7 / 2019 April 23" }
		'7.2.12066.0' { "SCOM 2016 Update Rollup 6 / 2018 October 23" }
		'7.2.12016.0' { "SCOM 2016 Update Rollup 5 / 2018 April 25" }
		'7.2.11938.0' { "SCOM 2016 Update Rollup 4 / 2017 October 23" }
		'7.2.11878.0' { "SCOM 2016 Update Rollup 3 / 2017 May 23" }
		'7.2.11822.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
		'7.2.11759.0' { "SCOM 2016 Update Rollup 1 / 2016 October 13" }
		'7.2.11719.0' { "SCOM 2016 RTM / 2016 September 26" }
		'7.2.11469.0' { "SCOM 2016 Technical Preview 5 / 2016 April" }
		'7.2.11257.0' { "SCOM 2016 Technical Preview 4 / 2016 July" }
		'7.2.11125.0' { "SCOM 2016 Technical Preview 3 / 2016 July" }
		'7.2.11097.0' { "SCOM 2016 Technical Preview 2 / 2016 June" }
		'7.2.10015.0' { "SCOM 2016 Update Rollup 2 / 2017 February 22" }
   <# 
      System Center Operations Manager 2012 R2 Versions
   #>
		'7.1.10226.1387' { "SCOM 2012 R2 Update Rollup 14 / 2017 November 28" }
		'7.1.10226.1360' { "SCOM 2012 R2 Update Rollup 13 / 2017 May 23" }
		'7.1.10226.1304' { "SCOM 2012 R2 Update Rollup 12 / 2017 January 24" }
		'7.1.10226.1239' { "SCOM 2012 R2 Update Rollup 11 / 2016 August 30" }
		'7.1.10226.1177' { "SCOM 2012 R2 Update Rollup 9 / 2016 January 26" }
		'7.1.10226.1118' { "SCOM 2012 R2 Update Rollup 8 / 2015 October 27" }
		'7.1.10226.1090' { "SCOM 2012 R2 Update Rollup 7 / 2015 August 11" }
		'7.1.10226.1064' { "SCOM 2012 R2 Update Rollup 6 / 2015 April 28" }
		'7.1.10226.1052' { "SCOM 2012 R2 Update Rollup 5 / 2015 February 10" }
		'7.1.10226.1046' { "SCOM 2012 R2 Update Rollup 4 / 2014 October 28" }
		'7.1.10226.1037' { "SCOM 2012 R2 Update Rollup 3 / 2014 July 29" }
		'7.1.10226.1015' { "SCOM 2012 R2 Update Rollup 2 / 2014 April 23" }
		'7.1.10226.1011' { "SCOM 2012 R2 Update Rollup 1 / 2014 January 27" }
		'7.1.10226.0' { "SCOM 2012 R2 RTM / 2013 October 22" }
   <# 
      System Center Operations Manager 2012 SP1 Versions
   #>
		'7.0.9538.0' { "SCOM 2012 SP1" }
		'7.0.9538.1005' { "SCOM 2012 SP1 Update Rollup 1 / 2013 January 8" }
		'7.0.9538.1047' { "SCOM 2012 SP1 Update Rollup 2 / 2013 April 08" }
		'7.0.9538.1069' { "SCOM 2012 SP1 Update Rollup 3 / 2013 July 23" }
		'7.0.9538.1084' { "SCOM 2012 SP1 Update Rollup 4 / 2013 October 21" }
		'7.0.9538.1106' { "SCOM 2012 SP1 Update Rollup 5 / 2014 January 27" }
		'7.0.9538.1109' { "SCOM 2012 SP1 Update Rollup 6 / 2014 April 23" }
		'7.0.9538.1117' { "SCOM 2012 SP1 Update Rollup 7 / 2014 July 29" }
		'7.0.9538.1123' { "SCOM 2012 SP1 Update Rollup 8 / 2014 October 28" }
		'7.0.9538.1126' { "SCOM 2012 SP1 Update Rollup 9 / 2015 February 10" }
		'7.0.9538.1136' { "SCOM 2012 SP1 Update Rollup 10 / 2015 August 11" }
   <# 
      System Center Operations Manager 2012 Versions
   #>
		'7.0.8289.0' { "SCOM 2012 Beta / 2011 July" }
		'7.0.8560.0' { "SCOM 2012 RTM" }
		'7.0.8560.1021' { "SCOM 2012 Update Rollup 1 / 2012 May 07" }
		'7.0.8560.1027' { "SCOM 2012 Update Rollup 2 / 2012 July 24" }
		'7.0.8560.1036' { "SCOM 2012 Update Rollup 3 / 2012 October 08" }
		'7.0.8560.1048' { "SCOM 2012 Update Rollup 8 / 2015 August 11" }
	}
	$setuplocation.CurrentVersion = $CurrentVersionSwitch + " (" + $setuplocation.CurrentVersion + ")"
	$setupOutput = [pscustomobject]@{
		'Product' = $setuplocation.Product
		'Installed On' = $setuplocation.InstalledOn
		'Current Version' = $setuplocation.CurrentVersion
		'Server Version' = $setuplocation.ServerVersion
		'UI Version' = $setuplocation.UIVersion
		'Management Server Port' = $setuplocation.ManagementServerPort
		'Management Servers in Management Group' = "$ManagementServers"
		'Database Server Name' = $setuplocation.DatabaseServerName
		'Operations Manager DB Name' = $setuplocation.DatabaseName
		'Data Warehouse DB Server Name' = $setuplocation.DataWarehouseDBServerName
		'Data Warehouse DB Name' = $setuplocation.DataWarehouseDBName
		'Installation Directory' = $setuplocation.InstallDirectory		
	}
	
	$generalinfo = $setupOutput | Out-File -FilePath "$OutputPath\General Information.txt"
	Write-Host "    Gathering General information from System Center Environement via Registry" -NoNewLine -ForegroundColor Cyan
	Write-Host "-" -NoNewline -ForegroundColor Green
	do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
	while ($generalinfo)
	Write-Host "> Completed!`n" -NoNewline -ForegroundColor Green
	
	
	
	
	
	write-output " "
	write-output "================================`n   Wrapping Up`n================================"
	Write-Host "Moving stuff around and zipping everything up for easy transport" -ForegroundColor Gray
	
	Move-Item $OutputPath\*.csv $OutputPath\csv
	Move-Item $OutputPath\*.evtx $OutputPath\eventlogs
	Move-Item $OutputPath\*.mta $OutputPath\eventlogs\localemetadata
	
	#Zip output
	$Error.Clear()
	Write-Host "`nCreating zip file of all CSV files." -ForegroundColor DarkCyan
	[Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null
	[System.AppDomain]::CurrentDomain.GetAssemblies() | Out-Null
	$SourcePath = Resolve-Path $OutputPath
	[string]$filedate = (Get-Date).tostring("MM_dd_yyyy")
	
	if ($CaseNumber)
	{
		[string]$destfilename = "SDC_Results_" + "$CaseNumber" + "_" + $filedate + ".zip"
	}
	else
	{
		[string]$destfilename = "SDC_Results_" + $filedate + ".zip"
	}
	
	[string]$destfile = "$ScriptPath" + "\" + "$destfilename"
	IF (Test-Path $destfile)
	{
		#File exists from a previous run on the same day - delete it
		Write-Host `n"-Found existing zip file: $destfile.`n Deleting existing file." -ForegroundColor DarkGreen
		Remove-Item $destfile -Force
	}
	$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
	$includebasedir = $false
	[System.IO.Compression.ZipFile]::CreateFromDirectory($SourcePath, $destfile, $compressionLevel, $includebasedir) | Out-Null
	IF ($Error)
	{
		Write-Error "Error creating zip file."
	}
	ELSE
	{
		Write-Host "`n-Cleaning up output directory." -ForegroundColor DarkCyan
		Remove-Item $OutputPath -Recurse
		Write-Host "`n--Saved zip file to: $destfile." -ForegroundColor Cyan
	}
	Write-Host "Script has completed" -ForegroundColor Green -NoNewline
	$x = 1
	do { $x++; Write-Host "." -NoNewline -ForegroundColor Green; Sleep 1 }
	until ($x -eq 3)
	Write-Output " "
	Write-Warning "Exiting script..."
	start C:\Windows\explorer.exe -ArgumentList "/select, $destfile"
	exit 0
}

if (($CheckTLSRegKeys -or $CheckCertificates -or $GetEventLogs -or $MSInfo32 -or $AssumeYes -or $ExportMPs -or $CaseNumber))
{
	Start-ScomDataCollector -CheckTLSRegKeys:$CheckTLSRegKeys -CheckCertificates:$CheckCertificates -GetEventLogs:$GetEventLogs -MSInfo32:$MSInfo32 -AssumeYes:$AssumeYes -ExportMPs:$ExportMPs -CaseNumber:$CaseNumber
}
else
{
	Start-ScomDataCollector
}
Write-Host "Something is wrong, Script has been stopped" -ForegroundColor Green -NoNewline
$x = 1
do { $x++; Write-Host "." -NoNewline -ForegroundColor Green; Sleep 1 }
until ($x -eq 3)
Write-Output " "
Write-Warning "Exiting script..."
exit 1


# SIG # Begin signature block
# MIIRKwYJKoZIhvcNAQcCoIIRHDCCERgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDS455tIQ+9OHCA
# fw7jN/kXcnUF+JiJgh6s5XyaYx045KCCDB4wggM3MIICI6ADAgECAhBid7E8Kyy6
# okrKDBZQBZ7/MAkGBSsOAwIdBQAwGTEXMBUGA1UEAxMOQW50aG9ueSBEdWd1aWQw
# IBcNMTcwNTI0MDIxNjI2WhgPMjE3NDAxMTUxNDAwMDBaMBkxFzAVBgNVBAMTDkFu
# dGhvbnkgRHVndWlkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3NXP
# 0qsalOagDYU6g7VAQqeqZYlICq+yClVDSBb+3DNSFIy8M2IogpocMT5wAwOvnBBO
# Yz34mgjqc03B7/uvXFDva1PW/4gRwL5jC+PJxg/FG4ghD+fRlKCDYC/55nNos04D
# P2APbkO1VLo9LjCVQRUfXjtbifOWtMHOzcw/AzY5PuxzLc5YCPXdXBCMw94aL4jX
# ABdkXp2o3kO9opsWkeZpG7VPsnGe0Ov4A0kHo5/33wVtNOWWQKDD8qJA/wZLDmKA
# aQX60/hJKzzV7P7hNKoWmUxBAILe/N/soprlj8m5Li+Avx82XumDyH8LPyUad2YL
# oNcsAZFcNokt3S+QlQIDAQABo4GAMH4wDwYDVR0TAQH/BAUwAwIBADAfBgNVHSUE
# GDAWBggrBgEFBQcDAwYKKwYBBAGCNwoDDTBKBgNVHQEEQzBBgBA0bMynuhE47c/y
# Vt4RcHC7oRswGTEXMBUGA1UEAxMOQW50aG9ueSBEdWd1aWSCEGJ3sTwrLLqiSsoM
# FlAFnv8wCQYFKw4DAh0FAAOCAQEALkbCgE0Z3XNqhtD+COhaMyN+CiifirdRVUwL
# jbwNjlq50x3MPx8Ty6/xs8W8nlM5Gl84S2LKDHYf/ycR/rR4L5BAR7HX1dLzVrbU
# DvoFA1r2vCwUdk0fODBASIb1reort7EyBX8ofE4neW6J6uMrvy8IGmWH4caAJ9jU
# o5pStCgn8aDvXS9Fx3nW+wwU3vUzcQYXXolnh0/EzB049/3KPhPQkWbZoxTRGSRb
# VnhrGIcvqLJN8fm5flG343Om32QDnzmEsQIWkjq8hiQXt4oIyLuoQoEcK52zPJ6R
# A44Icpr6kqYx/zjBrVdWL04cdNIFHles4CiiuOfkfIuxtXp+8DCCBBUwggL9oAMC
# AQICCwQAAAAAATGJxlAEMA0GCSqGSIb3DQEBCwUAMEwxIDAeBgNVBAsTF0dsb2Jh
# bFNpZ24gUm9vdCBDQSAtIFIzMRMwEQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQD
# EwpHbG9iYWxTaWduMB4XDTExMDgwMjEwMDAwMFoXDTI5MDMyOTEwMDAwMFowWzEL
# MAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExMTAvBgNVBAMT
# KEdsb2JhbFNpZ24gVGltZXN0YW1waW5nIENBIC0gU0hBMjU2IC0gRzIwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCqm47DqxFRJQG2lpTiT9jBCPZGI9lF
# xZWXW6sav9JsV8kzBh+gD8Y8flNIer+dh56v7sOMR+FC7OPjoUpsDBfEpsG5zVvx
# HkSJjv4L3iFYE+5NyMVnCxyys/E0dpGiywdtN8WgRyYCFaSQkal5ntfrV50rfCLY
# FNfxBx54IjZrd3mvr/l/jk7htQgx/ertS3FijCPxAzmPRHm2dgNXnq0vCEbc0oy8
# 9I50zshoaVF2EYsPXSRbGVQ9JsxAjYInG1kgfVn2k4CO+Co4/WugQGUfV3bMW44E
# Tyyo24RQE0/G3Iu5+N1pTIjrnHswJvx6WLtZvBRykoFXt3bJ2IAKgG4JAgMBAAGj
# gegwgeUwDgYDVR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0O
# BBYEFJIhp0qVXWSwm7Qe5gA3R+adQStMMEcGA1UdIARAMD4wPAYEVR0gADA0MDIG
# CCsGAQUFBwIBFiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5
# LzA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vY3JsLmdsb2JhbHNpZ24ubmV0L3Jv
# b3QtcjMuY3JsMB8GA1UdIwQYMBaAFI/wS3+oLkUkrk1Q+mOai97i3Ru8MA0GCSqG
# SIb3DQEBCwUAA4IBAQAEVoJKfNDOyb82ZtG+NZ6TbJfoBs4xGFn5bEFfgC7AQiW4
# GMf81LE3xGigzyhqA3RLY5eFd2E71y/j9b0zopJ9ER+eimzvLLD0Yo02c9EWNvG8
# Xuy0gJh4/NJ2eejhIZTgH8Si4apn27Occ+VAIs85ztvmd5Wnu7LL9hmGnZ/I1JgF
# snFvTnWu8T1kajteTkamKl0IkvGj8x10v2INI4xcKjiV0sDVzc+I2h8otbqBaWQq
# taai1XOv3EbbBK6R127FmLrUR8RWdIBHeFiMvu8r/exsv9GU979Q4HvgkP0gGHgY
# Il0ILowcoJfzHZl9o52R0wZETgRuehwg4zbwtlC5MIIExjCCA66gAwIBAgIMJFS4
# fx4UU603+qF4MA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYTAkJFMRkwFwYDVQQK
# ExBHbG9iYWxTaWduIG52LXNhMTEwLwYDVQQDEyhHbG9iYWxTaWduIFRpbWVzdGFt
# cGluZyBDQSAtIFNIQTI1NiAtIEcyMB4XDTE4MDIxOTAwMDAwMFoXDTI5MDMxODEw
# MDAwMFowOzE5MDcGA1UEAwwwR2xvYmFsU2lnbiBUU0EgZm9yIE1TIEF1dGhlbnRp
# Y29kZSBhZHZhbmNlZCAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEA2XhhoZauEv+j/yf2RGB7alYtZ+NfnzGSKkjt+QWEDm1OIlbK2JmXjmnKn3sP
# CMgqK2jRKGErn+Qm7rq497DsXmob4li1tL0dCe3N6D3UZv++IiJtNibPEXiX6VUA
# KMPpN069GeUXhEiyHCGt7HPS86in6V/oNc6FE6cim6yC6f7xX8QSWrH3DEDm0qDg
# TWjQ7QwMEB2PBV9kVfm7KEcGDNgGPzfDJjYljHsPJ4hcODGlAfZeZN6DwBRc4OfS
# XsyN6iOAGSqzYi5gx6pn1rNA7lJ/Vgzv2QXXlSBdhRVAz16RlVGeRhoXkb7BwAd1
# skv3NrrFVGxfihv7DShhyInwFQIDAQABo4IBqDCCAaQwDgYDVR0PAQH/BAQDAgeA
# MEwGA1UdIARFMEMwQQYJKwYBBAGgMgEeMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8v
# d3d3Lmdsb2JhbHNpZ24uY29tL3JlcG9zaXRvcnkvMAkGA1UdEwQCMAAwFgYDVR0l
# AQH/BAwwCgYIKwYBBQUHAwgwRgYDVR0fBD8wPTA7oDmgN4Y1aHR0cDovL2NybC5n
# bG9iYWxzaWduLmNvbS9ncy9nc3RpbWVzdGFtcGluZ3NoYTJnMi5jcmwwgZgGCCsG
# AQUFBwEBBIGLMIGIMEgGCCsGAQUFBzAChjxodHRwOi8vc2VjdXJlLmdsb2JhbHNp
# Z24uY29tL2NhY2VydC9nc3RpbWVzdGFtcGluZ3NoYTJnMi5jcnQwPAYIKwYBBQUH
# MAGGMGh0dHA6Ly9vY3NwMi5nbG9iYWxzaWduLmNvbS9nc3RpbWVzdGFtcGluZ3No
# YTJnMjAdBgNVHQ4EFgQU1Ie4jeblQDydWgZjxkWE2d27HMMwHwYDVR0jBBgwFoAU
# kiGnSpVdZLCbtB7mADdH5p1BK0wwDQYJKoZIhvcNAQELBQADggEBACRyUKUMvEAJ
# psH01YJqTkFfzseIOdPkfPkibDh4uPS692vhJOudfM1IrIvstXZMj9yCaQiW57rh
# Z7bwpr8YCELh680ZWDmlEWEj1hnXAOm70vlfQfsEPv6KIGAM0U8jWhkaGO/Yxt7W
# X1ShepPhtneFwPuxRsQJri9T+5WcjibiSuTE5jw177rG2bnFzc0Hm2O7PQ9hvFV8
# IxC1jIqj0mhFsUC6oN08GxVAuEl4b+WUwG1WSzz2EirUhfNIEwXhuzBFCkG3fJJu
# vk6SYILKW2TmVdPSB96dX5uhAe2b8MNduxnwGAyaoBzpaggLPelml6d1Hg+/KNcJ
# Iw3iFvq68zQxggRjMIIEXwIBATAtMBkxFzAVBgNVBAMTDkFudGhvbnkgRHVndWlk
# AhBid7E8Kyy6okrKDBZQBZ7/MA0GCWCGSAFlAwQCAQUAoEwwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwLwYJKoZIhvcNAQkEMSIEIB2cwFil4O32TJuZKf0x7mqf
# 8ZssoTh8kZV21sLWomc4MA0GCSqGSIb3DQEBAQUABIIBAKCaGlKAJga1L68sTKY7
# tw4+GrVQi6UpBnydRNu4ihtyz7M7oXVjUyBT5rwilbLD5FMsekzfNU5HW6S8Y6U2
# imDnxNm301WPqLpRrDqTrkgWDspQyrM02fYT5CeEl4TETlfWtHY/ugPyaOV/VX35
# s5EbxCX0msikOE6WCw5YW1kCf3fXPUjCw7Z+B64p6KTssO3DmZLzcyJlkVzxI6T0
# NuiKKNY/Be1GxHSrB0s0DWWHM2XINHv7/79wDo2D2pEmo0ytB2ivfhbnJLcJLo0T
# hV7ECNriKG4Z+f0tQV2M7JdZ6la9tsPYW6R4rYByAK5qubjiNRZ9Jpk3ZqwNC7Yh
# I+ChggK5MIICtQYJKoZIhvcNAQkGMYICpjCCAqICAQEwazBbMQswCQYDVQQGEwJC
# RTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTExMC8GA1UEAxMoR2xvYmFsU2ln
# biBUaW1lc3RhbXBpbmcgQ0EgLSBTSEEyNTYgLSBHMgIMJFS4fx4UU603+qF4MA0G
# CWCGSAFlAwQCAQUAoIIBDDAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yMDA3MjkwMTMxNDNaMC8GCSqGSIb3DQEJBDEiBCA3gPY6Lcua
# iL46ptZFidOCN+CS7DWZB/drOVtP/art8DCBoAYLKoZIhvcNAQkQAgwxgZAwgY0w
# gYowgYcEFD7HZtXU1HLiGx8hQ1IcMbeQ2UtoMG8wX6RdMFsxCzAJBgNVBAYTAkJF
# MRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMTEwLwYDVQQDEyhHbG9iYWxTaWdu
# IFRpbWVzdGFtcGluZyBDQSAtIFNIQTI1NiAtIEcyAgwkVLh/HhRTrTf6oXgwDQYJ
# KoZIhvcNAQEBBQAEggEAbr3bv1P/2HJkavg825ppfM5FRVOAvzQkrCIQdCR5v45V
# Bf5gQufyZODPETBoAVHwG/3xXPDwxf3vC+ilnNRUJMgg70XsJOoyy92dUbvcMiHf
# UqVG1So1itQI7BOLvznLivxR9sIXnLiID+kw47+dp0NFqu1jHhscSYq1ukMrtZPV
# 5cPJtdXXMY+Ieqr2X24zafwbGYas4hIONq57B8T0Uybjk8kwTZNBFMwMWK+1itoN
# IHB/TkWW347EfUbPPts0HUgCBPHD8adlPMFOgD2GzQWnIKt4vHM6KpPd1a6FOHYA
# yivknuCFbNXxp7eXsxen/Apx4Tgqdyq4xUBDZvrOuA==
# SIG # End signature block
