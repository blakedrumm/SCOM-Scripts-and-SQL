select Name AS 'ManagementPackID', Version, FriendlyName, DisplayName, Sealed, LastModified, TimeCreated 
from ManagementPackView
Where LanguageCode = 'ENU' OR LanguageCode IS NULL
order by Name