SELECT
   UserRoleName,
   IsSystem 
from
   UserRole