﻿<#
	.SYNOPSIS
		This script collects data from your SCOM Environment that can be very helpful in troubleshooting.
	
	.DESCRIPTION
		For full support, please run this script from a Management Server..
	
	.PARAMETER Servers
		Set additional servers to run checks against.
	
	.PARAMETER GetRunAsAccounts
		Get RunAs Accounts that are set on each Management Server.
	
	.PARAMETER GetEventLogs
		Gather Event Logs with the localemetadata to ensure that you are able to open the Event log from any machine.
	
	.PARAMETER CheckCertificates
		Check the Certificates for validity for SCOM use, output in TXT format.
	
	.PARAMETER CheckTLS
		Check for TLS Settings via Registry Keys, output in TXT format.
	
	.PARAMETER ExportMPs
		Export all Unsealed MP's.
	
	.PARAMETER MSInfo32
		Export MSInfo32 for viewing in TXT Format.
	
	.PARAMETER CaseNumber
		Add an Optional Case Number to the Output of the Zip File.
	
	.PARAMETER AssumeYes
		This will allow you to not be prompted for anything.
	
	.PARAMETER GenerateHTML
		Generate a HTML Report Page {EXPERIMENTAL}
	
	.PARAMETER All
		Allows you to Specify all the Switches Available for use.
	
	.EXAMPLE
		PS C:\> .\DataCollector.ps1 -Servers Agent1.contoso.com, Agent2.contoso.com -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -CaseNumber 0123456789 -GenerateHTML -AssumeYes
	
	.NOTES
		This script is intended for System Center Operations Manager Environments. This is currently in development by the SCEM Support Team with Microsoft.
		
		.VERSION
		v3.2.4 - November 11th, 2020
#>
[CmdletBinding()]
[OutputType([string])]
param
(
	[Parameter(Mandatory = $false,
			   Position = 1)]
	[Alias('s')]
	[Array]$Servers,
	[Parameter(Mandatory = $false,
			   Position = 2)]
	[Alias('gr')]
	[switch]$GetRunAsAccounts,
	[Parameter(Mandatory = $false,
			   Position = 3)]
	[Alias('ge')]
	[switch]$GetEventLogs,
	[Parameter(Mandatory = $false,
			   Position = 4)]
	[Alias('cc')]
	[switch]$CheckCertificates,
	[Parameter(Mandatory = $false,
			   Position = 5)]
	[Alias('ct')]
	[switch]$CheckTLS,
	[Parameter(Mandatory = $false,
			   Position = 6)]
	[Alias('em')]
	[switch]$ExportMPs,
	[Parameter(Mandatory = $false,
			   Position = 7)]
	[Alias('mi32')]
	[switch]$MSInfo32,
	[Parameter(Mandatory = $false,
			   Position = 8)]
	[Alias('case')]
	[string]$CaseNumber,
	[Parameter(Mandatory = $false,
			   Position = 9)]
	[Alias('assume')]
	[switch]$AssumeYes,
	[Parameter(Mandatory = $false,
			   Position = 10)]
	[Alias('html')]
	[switch]$GenerateHTML,
	[Parameter(Mandatory = $false,
			   Position = 11)]
	[switch]$All
)
$StartTime = Get-Date

Write-Host @"
===================================================================
==========================  Start of Script =======================
===================================================================
"@ -ForegroundColor DarkYellow
whoami
#Get the script path
[string]$ScriptPath = $PSScriptRoot
$currentPath = $myinvocation.mycommand.definition
$OutputPath = "$ScriptPath\Output"
$CSVFile = $ScriptPath

Get-Item $PSScriptRoot\Functions | Unblock-File | Out-Null

$scriptout = [Array] @()
[String]$Comp = Resolve-DnsName $env:COMPUTERNAME -Type A | Select-Object -Property Name -ExpandProperty Name
$checkingpermission = "Checking for elevated permissions..."
$scriptout += $checkingpermission
Write-Host $checkingpermission -ForegroundColor Gray
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
[Security.Principal.WindowsBuiltInRole] "Administrator"))
{
	$nopermission = "Insufficient permissions to run this script. Attempting to open the PowerShell script ($currentPath) as administrator."
	$scriptout += $nopermission
	Write-Warning $nopermission
	# We are not running "as Administrator" - so relaunch as administrator
	Start-Process powershell.exe "-File", ('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
	break
}
else
{
	$permissiongranted = " Currently running as administrator - proceeding with script execution..."
	Write-Host $permissiongranted -ForegroundColor Green
}
$omsdkUserOrig = (Get-WmiObject Win32_Service -Filter "Name='omsdk'").StartName -split '@'
$omsdkUserSplit = ($omsdkUserOrig)[0]
if ($omsdkUserOrig[1])
{
	$omsdkUser = $omsdkUserOrig[1] + "\" + $omsdkUserOrig[0]
}
$currentUser = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name).split('\')[1]

function Start-ScomDataCollector
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $false,
				   Position = 1)]
		[Array]$Servers,
		[Parameter(Mandatory = $false,
				   Position = 2)]
		[switch]$GetRunAsAccounts,
		[Parameter(Mandatory = $false,
				   Position = 3)]
		[switch]$GetEventLogs,
		[Parameter(Mandatory = $false,
				   Position = 4)]
		[switch]$CheckCertificates,
		[Parameter(Mandatory = $false,
				   Position = 5)]
		[switch]$CheckTLS,
		[Parameter(Mandatory = $false,
				   Position = 6)]
		[switch]$ExportMPs,
		[Parameter(Mandatory = $false,
				   Position = 7)]
		[switch]$MSInfo32,
		[Parameter(Mandatory = $false,
				   Position = 8)]
		[string]$CaseNumber,
		[Parameter(Mandatory = $false,
				   Position = 9)]
		[switch]$AssumeYes,
		[Parameter(Mandatory = $false,
				   Position = 10)]
		[switch]$GenerateHTML
	)
	
	if ($omsdkUserSplit -ne $currentUser)
	{
		do
		{
			if (!$AssumeYes)
			{
				$currentPathFormat = """$currentPath"""
				$answer = Read-Host "Would you like to run this script as the SDK Account ($omsdkUser)? (Y/N)"
			}
			else { $answer = "n" }
		}
		until ($answer -eq "y" -or $answer -eq "n")
		if ($answer -eq "y")
		{
			try { $Credentials = Get-Credential -Message "Please provide credentials to run this script with" $omsdkUser }
			catch { Write-Warning $_ }
			try { Start-Process powershell.exe -Credential $Credentials "-File", $currentPathFormat }
			catch { Write-Warning $_ }
			exit 0
		}
		
	}
	
	#=================================================================================
	#  SCOM Health SQL Query Collection Script
	#
	#  Author: Kevin Holman
	#  v1.5
	#  Heavily modified, with permission, by Michael Kallhoff (mikallho) & Blake Drumm (v-bdrumm) & Bobby King (v-bking)
	#=================================================================================
	# Constants section - modify stuff here:
	#=================================================================================
	#$OpsDB_SQLServer = "SQL2A.opsmgr.net"
	#$OpsDB_SQLDBName =  "OperationsManager"
	#$DW_SQLServer = "SQL2A.opsmgr.net"
	#$DW_SQLDBName =  "OperationsManagerDW"
	#=================================================================================
	# Begin MAIN script section
	#=================================================================================
	#Clear-Host
	# Check if this is running on a SCOM Management Server
	# Get SQLServer info from Registry if so
	Import-Module OperationsManager -ErrorAction SilentlyContinue
	$MSKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups"
	IF (Test-Path $MSKey)
	{
		# This is a management server.  Try to get the database values.
		$SCOMKey = "HKLM:\SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup"
		$SCOMData = Get-ItemProperty $SCOMKey
		$global:OpsDB_SQLServer = ($SCOMData).DatabaseServerName
		$global:OpsDB_SQLServerOriginal = $OpsDB_SQLServer
		$OpsDB_SQLDBName = ($SCOMData).DatabaseName
		$global:DW_SQLServer = ($SCOMData).DataWarehouseDBServerName
		$global:DW_SQLServerOriginal = $DW_SQLServer
		$DW_SQLDBName = ($SCOMData).DataWarehouseDBName
		$mgmtserver = 1
	}
	ELSE
	{
		if ($RemoteMGMTserver)
		{
			$ComputerName = $RemoteMGMTserver
		}
		else
		{
			$ComputerName = read-host "Please enter the name of a SCOM management server $env:userdomain\$env:USERNAME has permissions on"
		}
		$Hive = [Microsoft.Win32.RegistryHive]::LocalMachine
		$KeyPath = 'SOFTWARE\Microsoft\Microsoft Operations Manager\3.0\Setup'
		$OpsDBServer = 'DatabaseServerName'
		$OpsDBName = 'DatabaseName'
		$DWServer = 'DataWarehouseDBServerName'
		$DWDB = 'DataWarehouseDBName'
		$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($Hive, $ComputerName)
		$key = $reg.OpenSubKey($KeyPath)
		$OpsDB_SQLServerOriginal = $key.GetValue($OpsDBServer)
		$OpsDB_SQLDBName = $key.GetValue($OpsDBName)
		$DW_SQLServerOriginal = $key.GetValue($DWServer)
		$DW_SQLDBName = $key.GetValue($DWDB)
	}
	
	$Populated = 1
	
	. $ScriptPath`\Functions\SQL-Queries.ps1
	SQL-Queries
	
	#$TLSservers = import-csv $OutputPath\ManagementServers.csv
	$ManagementServers = Get-SCOMManagementServer | where { $_.IsGateway -eq $false } | Sort-Object DisplayName -Descending | Select-Object DisplayName -ExpandProperty DisplayName
	[string[]]$TLSservers = $ManagementServers
	[string[]]$TLSservers += $global:DW_SQLServer
	[string[]]$TLSservers += $global:OpsDB_SQLServer
	
	if ($Servers)
	{
		$Servers = ($Servers.Split(",").Split(" ") -replace (" ", ""))
		$Servers = $Servers | select -Unique
		foreach ($Server in $Servers)
		{
			[string[]]$TLSservers += $Server
		}
	}
	[array]$DNSCheckedServers = $null
	[string[]]$TLSservers = $TLSservers | select -Unique | Where { $null -ne $_ }
	try { $TLSservers | % { [array]$DNSCheckedServers += ([System.Net.Dns]::GetHostByName(("$_"))).Hostname } }
	catch { Write-Warning $_ }
	[array]$DNSVerifiedServers = [array]$DNSCheckedServers | select -Unique | Sort-Object
	#$TLSservers += "DC22"   # fictitious server added to simulate a no access/server down situation
	$DNSCount = ($DNSVerifiedServers).Count
	write-Output " "
	Write-Output "================================`nTesting Connectivity to Servers (Count: $DNSCount)"
	[string[]]$TestedTLSservers = @()
	foreach ($Rsrv in $DNSVerifiedServers)
	{
		Write-Host "  Testing $Rsrv" -ForegroundColor Gray
		$test = $null
		$test = test-path "\\$Rsrv\c$"
		if ($test)
		{
			Write-Host "    Successfully Accessed : $Rsrv" -ForegroundColor Green
			$TestedTLSservers += $Rsrv.Split(",")
		}
		else
		{
			Write-Host "    Access to $Rsrv Failed! Removing from Server Array! 
    Please verify that the server is online, and that your account has remote access to it.`n" -ForegroundColor Gray
		}
	}
	if ($GetRunAsAccounts)
	{
		Write-Output " "
		Write-Host "================================`nGathering RunAs Accounts" -NoNewLine
		. $ScriptPath`\Functions\Get-RunasAccount.ps1
		foreach ($RunAsSvr in $ManagementServers)
		{
			Write-Host "`n    Running against : " -NoNewline -ForegroundColor Gray
			Write-Host "$RunAsSvr" -NoNewline -ForegroundColor Cyan
			Get-SCOMRunasAccount -ManagementServer $RunAsSvr -OrderByAccount | ft * | Out-File $OutputPath\$RunAsSvr.RunAsAccountInfo.txt
		}
	}
	if ($CheckCertificates)
	{
		Write-Output " "
		Write-Output "================================`nStarting Certificate Checker"
		. $ScriptPath`\Functions\Certificate-Check.ps1
		foreach ($CertChkSvr in $TestedTLSservers)
		{
			SCOM-CertCheck -Servers $CertChkSvr | Out-String | Add-Content $OutputPath\$CertChkSvr.CertificateInfo.txt
		}
	}
	
	if ($CheckTLS)
	{
		Write-Output " "
		Write-Output "================================`nStarting TLS Checker"
		. $ScriptPath`\Functions\TLS-Checker.ps1
		Start-TLSChecker -Servers $TestedTLSservers
	}
	
	if ($GetEventLogs)
	{
		Write-Output " "
		Write-Output "================================`nStarting Event Log Gathering"
		. $ScriptPath`\Functions\Get-EventLog.ps1
		if ((Test-Path -Path "$OutputPath\Event Logs") -eq $false)
		{
			Write-Host "  Creating Folder: $OutputPath\Event Logs" -ForegroundColor Gray
			md "$OutputPath\Event Logs" | out-null
		}
		else
		{
			Write-Host "  Existing Folder Found: $OutputPath\Event Logs" -ForegroundColor Gray
			Remove-Item "$OutputPath\Event Logs" -Recurse | Out-Null
			Write-Host "   Deleting folder contents" -ForegroundColor Gray
			md "$OutputPath\Event Logs" | out-null
			Write-Host "    Folder Created: $OutputPath\Event Logs" -ForegroundColor Gray
		}
		foreach ($ElogServer in $TestedTLSservers)
		{
			Get-SCOMEventLogs -Servers $ELogServer
		}
		Write-Output " "
	}
	
	if ($ExportMPs)
	{
		try
		{
			if ($mgmtserver = 1)
			{
				Write-Output "================================`nStarting Unsealed MP Export"
				. $ScriptPath`\Functions\ExportMP.ps1
				MP-Export
    <#
        md $OutputPath\MPSealed | out-null
        try{
           (Get-SCOMManagementPack).where{$_.Sealed -eq $true} | Export-SCOMManagementPack -path $OutputPath\MPSealed
        }catch{
           
        }
    #>
				
			}
			else
			{
				Write-Warning "  Exporting Management Packs is only possible from a management server"
			}
		}
		catch { Write-Warning $_ }
	}
	
	if ($msinfo32)
	{
		write-output " "
		Write-Host "================================`nStarting MSInfo32 reporting"
		. $ScriptPath`\Functions\MsInfo32.ps1
		MSInfo32-Gathering
	}
	Write-Host "`n`n================================`nGathering Agent(s) Pending Management"
	$pendingMgmt = Get-SCOMPendingManagement | Out-File -FilePath "$OutputPath\Pending Management.txt"
	Write-Host "    Running Powershell Command: " -NoNewLine -ForegroundColor Cyan
	Write-Host "`n      Get-SCOMPendingManagement" -NoNewLine -ForegroundColor Magenta
	Write-Host " against" -NoNewLine -ForegroundColor Cyan
	Write-Host " $env:COMPUTERNAME" -NoNewLine -ForegroundColor Magenta
	Write-Host "-" -NoNewline -ForegroundColor Green
	do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
	while ($pendingMgmt)
	Write-Host "> Command Execution Completed!`n" -NoNewline -ForegroundColor Green
	
	write-Output " "
	Write-Output "================================`nGathering System Center Operations Manager General Information"
	Write-Host "    Executing Function" -NoNewLine -ForegroundColor Cyan
	Write-Host "-" -NoNewline -ForegroundColor Green
	. $ScriptPath`\Functions\General-Info.ps1
	$collectCompleted = Get-SCOMGeneralInfo -Servers $TestedTLSservers
	do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
	until ($collectCompleted)
	Write-Host "> Completed!`n" -NoNewline -ForegroundColor Green
	
	if ($GenerateHTML)
	{
		Write-Output "`n================================`nGenerating System Center Operations Manager Report Webpage"
		. $ScriptPath`\Functions\Report-Webpage.ps1
		Write-Host "    Generating Report Webpage to be viewed in a Web Browser" -NoNewLine -ForegroundColor Cyan
		Write-Host "-" -NoNewline -ForegroundColor Green
		$reportWebpageCompleted = Report-Webpage
		do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
		until ($reportWebpageCompleted)
		Write-Host "> Completed!`n" -NoNewline -ForegroundColor Green
	}
	write-output " "
	write-output "================================`n   Wrapping Up`n================================"
	Write-Host "Moving stuff around and zipping everything up for easy transport" -ForegroundColor Gray
	. $ScriptPath`\Functions\Wrapping-Up.ps1
	Wrap-Up
	Write-Host "Script has completed" -ForegroundColor Green -NoNewline
	$x = 1
	do { $x++; Write-Host "." -NoNewline -ForegroundColor Green; Sleep 1 }
	until ($x -eq 3)
	Write-Output " "
	Write-Warning "Exiting script..."
	start C:\Windows\explorer.exe -ArgumentList "/select, $destfile"
	exit 0
}

if (($CheckTLS -or $CheckCertificates -or $GetEventLogs -or $MSInfo32 -or $AssumeYes -or $ExportMPs -or $CaseNumber -or $Servers -or $GenerateHTML -or $GetRunAsAccounts -or $All))
{
	if ($all)
	{
		if ($Servers)
		{
			Start-ScomDataCollector -Servers $Servers -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -AssumeYes
		}
		else
		{
			Start-ScomDataCollector -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -AssumeYes
		}
	}
	else
	{
		Start-ScomDataCollector -Servers $Servers -GetRunAsAccounts:$GetRunAsAccounts -CheckTLS:$CheckTLS -CheckCertificates:$CheckCertificates -GetEventLogs:$GetEventLogs -MSInfo32:$MSInfo32 -ExportMPs:$ExportMPs -CaseNumber:$CaseNumber -GenerateHTML:$GenerateHTML -AssumeYes:$AssumeYes
	}
}
else
{
	# Enter Switches here that you want to run if no switches are specified during runtime.
	Start-ScomDataCollector -AssumeYes
}
Write-Host "Something is wrong, Script has been stopped" -ForegroundColor Green -NoNewline
$x = 1
do { $x++; Write-Host "." -NoNewline -ForegroundColor Green; Sleep 1 }
until ($x -eq 3)
Write-Output " "
Write-Warning "Exiting script..."
exit 1