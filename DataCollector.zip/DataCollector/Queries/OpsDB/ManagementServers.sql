SELECT *
FROM MTV_HealthService
WHERE IsManagementServer = 1
OR IsGateway = 1
ORDER BY DisplayName